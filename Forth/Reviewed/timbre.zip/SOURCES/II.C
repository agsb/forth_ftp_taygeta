/* Inner interpreters  Rob Chapman  Jul 21, 1992 */

#include "botforth.h"	/* stacks and stuff */
#include "ii.h"

extern void end_program();

/* : vii  ( -- a )  ip @ @  CELL + ;  */
void VII()	/* -- ii */
{
	*--sp=(Cell)(tick+1);
}

/* : cii  ( -- n )  vii @ ; */
void CII()	/* -- ii */
{
	*--sp=(Cell)*(tick+1);
}

/*
  : EXECUTE  ( tick -- )  DUP tick !  @ JSR ;
  : ITC  ( -- )  BEGIN  ip @  @+  ip !  ?DUP  WHILE  EXECUTE  REPEAT ;
  : :II  ( -- )  ip @ >R  tick @ CELL + ip !  ITC  R> ip ! ;
*/
void COLON_II()  /* -- ii */
{
	*--rp=(Cell)ip;
	ip=(void (***)())(tick+1);
	while((tick=*ip++) != 0)
	{
		TestTick;(**tick)();	  /* EXECUTE */
	}
	ip=(void (***)())*rp++;
}

/*
  : doesii  ( -- )  ip @ >R  tick @ CELL +  @+ SWAP  ip !  ITC  R> ip ! ;
*/
void DII()  /* -- ii */
{
	*--rp=(Cell)ip;
	ip=(void (***)())(*(tick+1));
	*--sp=(Cell)(tick+2);
	while((tick=*ip) != 0)
	{
		ip++;
		TestTick;(**tick)();	  /* EXECUTE */
	}
	ip=(void (***)())*rp++;
}
