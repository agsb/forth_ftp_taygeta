/* Combine terminators here for ending programs  Rob Chapman  May 9, 1993 */

/* called when program is ending for tying up loose ends */
void end_program(char *message)
{
	restore_io();
	puts(message);
	exit(0);
}
