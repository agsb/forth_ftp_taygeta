/* Final dictionary links  Rob Chapman  Mar 18, 1993 */

#include "botforth.h"

/* last word in each header file */
extern void *_main;
extern void *_STDOUT;
extern void *_setup_io;
extern void *_LD;
extern void *_WORDS;
extern void *_AOBJ_FILE;
extern void *_W_DOT_ERRORS;
extern void *_SH_STORE;
extern void *_END;
extern void *_DII;
extern void *_DOT_RULES;
extern void *_INIT_1;
	
/* Define start of each list and tie the header files together */
const TIE _kernel =	{0,0x80};		/* list end */
const TIE _io =		{&_main,0x80};
const TIE _localio =	{&_STDOUT,0x80};
const TIE _file_=	{&_setup_io,0x80};
const TIE _library=	{&_LD,0x80};
const TIE _aoloader=	{&_WORDS,0x80};
const TIE _xtras=	{&_AOBJ_FILE,0x80};
const TIE _shells=	{&_W_DOT_ERRORS,0x80};
const TIE _timeout=	{&_SH_STORE,0x80};
const TIE _ii=		{&_END,0x80};
const TIE _timbre=	{&_DII,0x80};
const TIE _auto=	{&_DOT_RULES,0x80};
const TIE _listhead=	{&_INIT_1,0x80};	/* list start */
