
char* MEMORY =


"CMOVE "
"Stack: ( addr1 addr2 n --- )"
"Usage: Move <n> bytes from memory (source = addr2) to memory (dest. = addr1)."
"       This word can move data with overlays."


"FILL "
"Stack: ( addr n c --- )"
"Usage: Fill <n> bytes from memory <addr) with character <c>."


"MEMFREE "
"Stack: ( --- n )"
"Usage: Give the amount of free memory still available for code and data."
"  See: mem DataSalvage"


"@ "
"Stack: ( addr --- n )"
"Usage: Read the 32-bits value stored at location <addr>."
"  See: C@ W@ ! INT ALLOT"


"(@) "
"Stack: ( addr --- n )"
"Usage: Read the 32-bits value stored at location <addr>, with no memory protection."
"  See: (W@) (C@) (C!) (W@) (W!)"


"[@] "
"  Stack: ( addr --- n )"
"  Usage: Read the 32-bits value stored at 'raw' location <addr>, with no"
"         memory protection. This the real address, so [@] will be useful"
"         to read into ROM space."
"Example: // Read VGA ROM to see if a PARADISE SuperVGA card"
"         0xC007D [@]"
"    See: @ ! (@) (!)  [W@] [C@]"


"C@ "
"Stack: ( addr --- c )"
"Usage: Read the byte value stored at location <addr>."
"  See: @ W@ ! C! INT ALLOT"


"(C@) "
"Stack: ( addr --- c )"
"Usage: Read the byte value stored at location <addr>, with no memory protection."
"  See: (@) (W@) (C!) (W@) (W!)"


"[C@] "
"  Stack: ( addr --- b )"
"  Usage: Read the 8-bits value stored at 'raw' location <addr>, with no"
"         memory protection. This the real address, so [C@] will be useful"
"         to read into ROM space."
"    See: @ ! (@) (!)  [@] [W@]"


"W@ "
"Stack: ( addr --- w )"
"Usage: Read the 16-bits value stored at location <addr>."
"  See: @ C@ ! W! INT ALLOT"


"(W@) "
"Stack: ( addr --- w )"
"Usage: Read the 16-bits value stored at location <addr>, with no memory protection."
"  See: (@) (C@) (C!) (W@) (W!)"


"[W@] "
"  Stack: ( addr --- w )"
"  Usage: Read the 16-bits value stored at 'raw' location <addr>, with no"
"         memory protection. This the real address, so [W@] will be useful"
"         to read into ROM space."
"    See: @ ! (@) (!)  [@] [C@]"


"! "
"Stack: ( n addr --- )"
"Usage: Write a 32-bits value into location at address <addr>."
"  See: C! W! @ INT ALLOT"


"(!) "
"Stack: ( n addr --- )"
"Usage: Write a 32-bits value into location at address <addr>, with no memory protection."
"  See: C! W! @ INT ALLOT"


"C! "
"Stack: ( b addr --- )"
"Usage: Write a byte value into location at address <addr>."
"  See: ! W! @ C@ INT ALLOT"


"(C!) "
"Stack: ( b addr --- )"
"Usage: Write a byte value into location at address <addr>, with no memory protection."
"  See: ! W! @ C@ INT ALLOT"


"W! "
"Stack: ( w addr --- )"
"Usage: Write a 16-bits value into location at address <addr>."
"  See: ! C! @ W@ INT ALLOT"


"(W!) "
"Stack: ( w addr --- )"
"Usage: Write a 16-bits value into location at address <addr>, with no memory protection."
"  See: ! C! @ W@ INT ALLOT"


"+! "
"Stack: ( n addr --- )"
"Usage: Add the value <n> to the integer variable at location <addr>."
"  See: @ ! INT -!"


"-! "
"Stack: ( n addr --- )"
"Usage: Sub the value <n> to the integer variable at location <addr>."
"  See: @ ! INT +! *! /!"


"*! "
"Stack: ( n addr --- )"
"Usage: Multiply the value <n> to the integer variable at location <addr>."
"  See: @ ! INT +! -! /!"


"/! "
"Stack: ( n addr --- )"
"Usage: Divide the value <n> to the integer variable at location <addr>."
"  See: @ ! INT +! -! */"


"? "
"Stack: ( addr --- )"
"Usage: Print the 32-bits value stored at location <addr>, in the current"
"       base for integer numeric I/O."
"  See: BASE INT @ ! C? W?"


"C? "
"Stack: ( addr --- )"
"Usage: Print the 8-bits value stored at location <addr>, in the current"
"       base for integer numeric I/O."
"  See: BASE INT C@ C! ? W?"


"W? "
"Stack: ( addr --- )"
"Usage: Print the 16-bits value stored at location <addr>, in the current"
"       base for integer numeric I/O."
"  See: BASE INT W@ W! ? C?"


"DataSalvage "
"Stack: ( --- n )"
"Usage: This word returns the amount of data memory which will be recovered"
"       if DUST (garbage collector) is called."
"  See: DUST DustTreshold INFOS"


"Dust "
"Stack: ( --- )"
"Usage: This is the garbage collector. Due to dynamic allocation, data memory"
"       memory can be fragmented. FORGET calls automatically DUST."
"  See: DataSalvage DustTreshold INFOS"


"DustThreshold "
"Stack: ( --- addr )"
"Usage: This variable, if not with -1, give a value, if reached by DATASALVAGE,"
"       then a call do DUST is made."
"  See: DataSalvage Dust INFOS"


"?AllotFail "
"Stack: ( --- addr )"
"Usage: This variable, when set with TRUE value, brings an error if ALLOT fail"
"       due to out of memory (remember that FROTH allows using all expanded memory)."
"       Is set with FALSE, ALLOT returns -1 value."
"  See: BUILD> DOES>  ALLOT BALLOT WALLOT"


""
;
