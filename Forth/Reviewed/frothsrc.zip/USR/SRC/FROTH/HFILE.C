char* FILEIO =


"FILEIOSTATUS "
"Stack: ( --- n )"
"Usage: Return the status of the last file I/O definitions ran. Status is"
"      the MS/DOS error code."
"  See: Open-File Close-File etc..."


"R/O "
"Stack: ( --- n )"
"Usage: Constant used with OPEN-FILE to specify that given file is opened"
"       in Read Only mode."
"  See: W/O R/W Open-File"


"W/O "
"Stack: ( --- n )"
"Usage: Constant used with OPEN-FILE to specify that given file is opened"
"       in Write Only mode."
"  See: R/O R/W Open-File"


"R/W "
"Stack: ( --- n )"
"Usage: Constant used with OPEN-FILE to specify that given file is opened"
"       in Read qnd Write mode."
"  See: R/O W/O Open-File"


"Open-File "
"Stack: ( addrz n --- fh )"
"Usage: Open the file with the given filename <addrz>. <n> is access mode"
"       (R/O, W/O or R/W). File is created if access mode is W/O or R/W and"
"       if file does not exist (in this case FILEIOSTATUS has the special"
"       value 3, else 2 if not creation). The file handle is returned if OK,"
"       else -1 if error (see FILEIOSTATUS in this case)."
"  See: FILEIOSTATUS R/O W/O R/W Close-File Read-File Write-File"


"Close-File "
"Stack: ( fh --- )"
"Usage: Close the file, with given file handle <fh>. FILEIOSTATUS must be"
"       be called to see if no error occured."
"  See: FILEIOSTATUS Open-File"


"Emit-File "
"Stack: ( fh c --- n )"
"Usage: Send the given character <c> to a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS Type-File Write-File Open-File Close-File"


"Write-File "
"Stack: ( fh addr n1--- n2 )"
"Usage: Send <n1> characters starting at address <addr> to a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS Emit-File Type-File Open-File Close-File"


"Read-File "
"Stack: ( fh addr n1--- n2 )"
"Usage: Read <n1> characters starting at address <addr> from a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters read from file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error). The"
"       pseudo-constant ?EOF is updated if end-of-file is reached."
"  See: FILEIOSTATUS Write-File Open-File Close-File Read-Line ?eof"


"LINESEP$ "
"Stack: ( --- addrz )"
"Usage: This string is used as line separator by READ-LINE and WRITE-LINE."
"       You must initialize this string in the STARTUP.FTH file with value"
"	such \"\\0D\\0A\" (MS-DOS) or \"\\0D\" (UNIX)"
"  See: Read-Line Write-Line"


"Write-Line "
"Stack: ( fh addrz --- n )"
"Usage: Send the given string <addrz> to a given opened file, of file handle <fh>."
"       Is returned the number of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error). The string"
"       LINESEP$ is used as line separator."
"  See: FILEIOSTATUS Open-File Close-File Emit-File Write-File Write-Line"
"       LineSep$"


"Read-Line "
"Stack: ( fh addrz n1 --- n2 )"
"Usage: Read next line from file (from current seek position) to the given"
"       string <addrz> from the given opened file <fh>."
"       <n1> is the max number of char which can be read. Is returned the"
"       number of characters read from file (w/o line separator), or -1 if"
"       error (in this case, call FILEIOSTATUS to know the error). The"
"       string LINESEP$ is used as line separator. The pseudo-constant ?EOF"
"       is updated if end-of-file is reached."
"  See: FILEIOSTATUS Open-File Close-File Read-File Read-Line"
"       LineSep$ ?EOF"


"?EOF "
"Stack: ( fh --- f )"
"Usage: Return a flag <f> which is TRUE if end-of-file was reached from"
"       file <fh> by words such READ-FILE and READ-LINE."
"  See: READ-FILE READ-LINE LINESEP$"


"SEEKSET "
"Stack: ( --- 0 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from begin of file."
"  See: SEEKCUR SEEKEND Reposition-File File-Position"


"SEEKCUR "
"Stack: ( --- 1 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from current pointer position of file."
"  See: SEEKSET SEEKEND Reposition-File File-Position"


"SEEKEND "
"Stack: ( --- 2 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from end of file."


"Reposition-File "
"Stack: ( fh n1 n2 --- n3 )"
"Usage: Move file pointer (current position into the file of handle <fh>),"
"       with method <n1> (SEEKSET, SEEKCUR or SEEKEND) and offset <n2>."
"  See: SEEKSET SEEKCUR SEEKEND File-Position"


"File-Position "
"Stack: ( fh --- n )"
"Usage: Return the current position into opened file of handle <fh>. This value is"
"       always expressed from the begin of file."
"  See: SEEKSET SEEKCUR SEEKEND Reposition-File File-Position"


"File-Size "
"Stack: ( fh --- n )"
"Usage: Return the length of the opened file of handle <fh>. Calling this word"
"       has NOT the side effect to move file pointer."
"  See: SEEKSET SEEKCUR SEEKEND Reposition-File File-Position"


"Delete-File "
"Stack: ( addrz --- )"
"Usage: Delete a file with given filename <addrz>."
"  See: Open-File ?FileExist"


"?FileExist "
"Stack: ( addrz --- n )"
"Usage: Return a flag which tells if a file of the given filename <addrz> exists."
"  See: Open-File"


""
;
