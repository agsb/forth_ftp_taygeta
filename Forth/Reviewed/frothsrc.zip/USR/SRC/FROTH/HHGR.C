char* HGR =


"320x200x16 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x0D)."


"640x200x16 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x0E)."


"640x350x4 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x0F)."


"640x350x16 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x10)."


"640x480x2 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x11)."


"640x480x16 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x12)."


"320x200x256 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode (BIOS mode 0x13)."


"800x600x16 "
"Stack: ( --- )"
"Usage: Selection of the given graphics mode. Because it's a super VGA mode,"
"       you must give the BIOS video mode (it's often 0x58)."


"#grows "
"Stacks: ( --- n )"
"Usage: Return the number of pixels (height) available under the current graphics mode."
"  See: #gcols #gcolors #gpages"


"#gcols "
"Stacks: ( --- n )"
"Usage: Return the number of pixels (width) available under the current graphics mode."
"  See: #grows #gcolors #gpages"


"#gcolors "
"Stacks: ( --- n )"
"Usage: Return the number of colors available under the current graphics mode."
"  See: #gcols #grows #gpages"


"#gpages "
"Stacks: ( --- n )"
"Usage: Return the number of pages available under the current graphics mode."
"  See: #gcols #grows #gcolors"


"SetPixel "
"Stack: ( x y o --- )"
"Usage: Set a pixel at (x, y) {x is column, y is row} with color <o>."
"  See: GetPixel 800x600"


"GetPixel "
"Stack: ( x y --- o )"
"Usage: Get the color <o> of a pixel at (x, y) {x is column, y is row}."
"  See: SetPixel 800x600"


"FILLED "
"Stack: ( --- n )"
"Usage: Constant to be used in some graphic functions, which has the meaning:"
"       fill area of the asked figure."
"  See: NOTFILLED box triangle ... "


"NOTFILLED "
"Stack: ( --- n )"
"Usage: Constant to be used in some graphic functions, which has the meaning:"
"       do not fill area of the asked figure."
"  See: FILLED box triangle ... "


"GMODE_COPY "
"Stack: ( --- n )"
"Usage: Specify that further graphics draw will be done with no logical operation"
"       between given color and screen color."
"  See: GMODE_XOR GMODE_AND GMODE_OR GMODE"


"GMODE_XOR "
"Stack: ( --- n )"
"Usage: Specify that further graphics draw will be"
"       done with XOR logical operation between given color and screen color."
"  See: GMODE_COPY GMODE_AND GMODE_OR GMODE"


"GMODE_OR "
"Stack: ( --- n )"
"Usage: Specify that further graphics draw will be"
"       done with OR logical operation between given color and screen color."
"  See: GMODE_COPY GMODE_XOR GMODE_AND GMODE"


"GMODE_AND "
"Stack: ( --- n )"
"Usage: Specify that further graphics draw will be"
"       done with XOR logical operation between given color and screen color."
"  See: GMODE_COPY GMODE_XOR GMODE_OR GMODE"


"CLIP "
"Stack: ( x1 y1 x2 y2 --- )"
"Usage: Specify a clipping region for further graphics draw."


"CLEAR "
"Stack: ( color --- )"
"Usage: Clear the entire graphics screen, with the given color."


"LINE "
"Stack: ( x1 y1 x2 y2 color --- )"
"Usage: Draw a line between 2 points, with a given color. Logical operation between"
"       given color and screen color is made, according settings made by GMODE_xxx."
"  See: HLINE VLINE  CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"


"HLINE "
"Stack: ( y x1 x2 color --- )"
"Usage: Draw an horizontal line between 2 points, with a given color. Logical operation between"
"       given color and screen color is made, according settings made by GMODE."
"  See: LINE VLINE   CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"


"VLINE "
"Stack: ( x y1 y2 color --- )"
"Usage: Draw a vertical line between 2 points, with a given color. Logical operation between"
"       given color and screen color is made, according settings made by GMODE."
"  See: HLINE LINE  CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"


"BOX "
"Stack: ( x1 y1 x2 y2 color f --- )"
"Usage: Draw a rectangle, with a given color. Top left corner is (x1, y1). Right bottom"
"       corner is (x2, y2). Restangle is filled or not, according of flag <f>. Logical"
"       operation between given color and screen color is made, according settings"
"       made by GMODE."
"  See: LINE HLINE VLINE  CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"


"VIDEOREGION "
"This is a defining-word."
"Stack: Compile-time: ( x y --- )"
"           Run-time: ( --- addr )"
"       Input stream: VIDEOREGION <name>"
"Usage: This defining-word is used to build a word which will be used to save/restore"
"       video regions. <x> and <y> are the size of the rectangular area."
"Example:     100 150 VideoRegion SavedZone     // The zone to save is 100x150"
"             50 75 SavedZone GetVideo          // Read screen, save zone"
"             90 25 SavedZone PutVideo          // Restore elsewhere this zone"
"See also: GetVideo PutVideo"


"GETVIDEO "
"Stack: ( x y addr --- )"
"Usage: Read from the screen a rectangular area from (x, y) and save-it into"
"       the given buffer (created beforehand with VIDEOREGION)."
"  See: VideoRegion PutVideo"


"PUTVIDEO "
"Stack: ( x y addr --- )"
"Usage: Write on screen at (x, y) the given rectangular zone saved into the"
"       given buffer."
"  See: VideoRegion GetVideo"


"SPRITE "
"This is a defining-word."
"Stack: Compile-time: ( x y --- )"
"           Run-Time: ( --- addr )"
"       Input stream: SPRITE <name>"
"Usage: This word is used to create a sprite object. The sprite will be then"
"       defined with the two words >COLOR_SPRITE and >SPRITE. The sprite will be"
"       initialized with the word INIT_SPRITE. The sprite will be draw at a given"
"       screen location with DRAW_SPRITE."
"Example:  5 7 SPRITE mySprite"
"          '. black  mySprite >color_sprite"
"          'X red    mySprite >color_sprite"
"          'O yellow mySprite >color_sprite"
"          0 \" ..XXX..\" mySprite >sprite"
"          1 \" .X...X.\" mySprite >sprite"
"          2 \" X.OOO.X\" mySprite >sprite"
"          3 \" X.OOO.X\" mySprite >sprite"
"          4 \" .X...X.\" mySprite >sprite"
"          5 \" ..XXX..\" mySprite >sprite"
"  See: >COLOR_SPRITE >SPRITE INIT_SPRITE DRAW_SPRITE CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"
" Note: A graphics mode must be active prio to use SPRITE."


">COLOR_SPRITE "
"Stack: ( c n addr --- )"
"Usage: This word is used to define an association betweeen a character and a"
"       color: this then will be used by the word >COLOR."
"  See: >SPRITE >SPRITE INIT_SPRITE DRAW_SPRITE CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"
"Example: See example given in SPRITE (use SPRITE)"


">SPRITE "
"Stack: ( n addrz addr --- )"
"Usage: This word is used to define the <n>th line of the given sprite (addr)."
"  See: >COLOR_SPRITE >SPRITE INIT_SPRITE DRAW_SPRITE CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"
"Example: See example given in SPRITE (use SPRITE)"


"INIT_SPRITE "
"Stack: ( addr --- )"
"Usage: This word initialize the given sprite."
"  See: >COLOR_SPRITE >SPRITE SPRITE DRAW_SPRITE CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"
"Example: See example given in SPRITE (use SPRITE)"


"DRAW_SPRITE "
"Stack: ( addr --- )"
"Usage: This word draw the given sprite at (x, y)."
"  See: >COLOR_SPRITE >SPRITE SPRITE DRAW_SPRITE CLIP  GMODE_COPY GMODE_OR GMODE_AND GMODE_XOR"
"Example: See example given in SPRITE (use SPRITE)"


""
;
