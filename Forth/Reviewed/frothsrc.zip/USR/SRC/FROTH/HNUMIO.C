char* NUMIO =


"BASE "
"Stack: ( --- adr )"
"Usage: Variable which contains the base for integer numeric I/O."
"  See: <# # U# #S U#S SIGN HOLD #> DECIMAL HEX . U."


"DECIMAL "
"Stack: ( --- )"
"Usage: Select decimal base for integer numeric I/O."
" Note: This is an immediate word, so it can't be compiled."
"  See: BASE HEX NUMBER"


"HEX "
"Stack: ( --- )"
"Usage: Selection hexadecimal base (16) for integer numeric I/O."
" Note: This is an immediate word, so it can't be compiled."
"  See: BASE DECIMAL NUMBER"


"<# "
"Stack: ( n --- n )"
"Usage: Start integer numeric conversion processus."
"  See: # U# #S U#S hold sign #>"


"# "
"Stack: ( n1 --- n2 )"
"Usage: signed integer numeric conversion processus: generate the next digit in"
"       the pictured output string. <n1> is divided by the current I/O number,"
"       base leaving the quotient <n2> for further processing."
"  See: <# U# #S U#S hold sign #> bas"


"U# "
"Stack: ( u1 --- u2 )"
"Usage: unsigned integer numeric conversion processus: generate the next digit"
"       in the pictured output string. <n1> is divided by the current I/O number,"
"       base leaving the quotient <n2> for further processing."
"  See: <# # U# #S U#S hold sign #> base"


"HOLD "
"Stack: ( c --- )"
"Usage: Insert the given character into the next location of a pictured output"
"      string."
"  See: <# # U# #S U#S sign #> base"


"SIGN "
"Stack: ( n --- n )"
"Usage: If <n> was negative, insert the negative sign into the next location of"
"      a pictured output."
"  See: <# # U# #S U#S hold #> base"


"#S "
"Stack: ( n --- 0 )"
"Usage: Complete signed integer numeric conversion processus: generate the ascii"
"      characters for the pictured numeric output string, corresponding to"
"      number <n>, character by character, until a zero remainder is found."
"      At least one digit is generated."
"  See: <# # U# U#S hold sign #> base"


"U#S "
"Stack: ( un --- 0 )"
"Usage: Complete unsigned integer numeric conversion processus: generate the"
"      ascii characters for the pictured numeric output string, corresponding"
"      to number <un>, character by character, until a zero remainder is found."
"      At least one digit is generated."
"  See: <# U# hold U# #> base"


"#> "
"Stack: ( n --- addrz )"
"Usage: End conversion of a number. The 1st (leftmost) character of the"
"      resulting pictured output string is located at <addrz>. The string"
"      is ready to be print with TYPE."
"  See: <# # U# hold sign #S U#S base"


"<#S> "
"Stack: ( n --- addrz )"
"Usage: Do the string conversion of a number. The 1st (leftmost) character"
"      of the resulting pictured output string is located at <addrz>. The"
"      string is ready to be print with TYPE."
" Note: This definition is coded as:"
"         : <#S> <# #S #> ;"
"  See: <# # U# hold sign #S U#S base"


"NUMBER "
"Stack: ( adr --- n tf )      if conversion is OK"
"   or: ( adr --- ff )        if conversion is not OK."
"Usage: Try to convert a string (endded by '\0') to a number, according to the"
"       current base for integer numeric I/O. If the conversion is OK, the"
"       number and a true flag (1) are left on the stack. Else, only the false"
"       flag is left on the stack."
"  See: base decimal hex <# # U# #S U#S sign hold #>"


". "
"Stack: ( n --- )"
"Usage: Print the top integer value, in the current base for numeric I/O."
"       The number is intepreted as a signed integer."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> .R U. H."


".R "
"Stack: ( n1 n2 --- )"
"Usage: Print an integer value <n1>, in the current base for numeric I/O."
"       The number is intepreted as a signed integer.  The number is justified"
"       in a right field of length <n2>."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> . .L U. H."


".L "
"Stack: ( n1 n2 --- )"
"Usage: Print an integer value <n1>, in the current base for numeric I/O."
"       The number is intepreted as a signed integer.  The number is justified"
"       in a left field of length <n2>."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> . .R U. H."


"U. "
"Stack: ( un --- )"
"Usage: Print the top integer value, in the current base for numeric I/O."
"       The number is intepreted as an unsigned integer."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> . H."


"H. "
"Stack: ( n --- )"
"Usage: Print the top integer value, in hexadecimal. The number is intepreted"
"       as an unsigned integer."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> . U. H. 02H."


"02H. "
"Stack: ( c --- )"
"Usage: Print the top integer value, in hexadecimal and on two digits. The"
"       number is intepreted as an unsigned byte."
"  See: Base Decimal Hex <# # U# #S U#S Sign Hold #> . U. H."


""
;
