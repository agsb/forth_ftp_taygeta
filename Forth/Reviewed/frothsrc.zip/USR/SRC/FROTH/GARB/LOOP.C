#include <stdio.h>


char huge tab[1000][500];

main(void)

	{
	int	x, y;

	for (x = 0; x < 1000; x++)
		{
		for (y = 0; y < 500; y++)
			{
			tab[x][y] = 0;
			}
		}

	return (0);
	} // main
