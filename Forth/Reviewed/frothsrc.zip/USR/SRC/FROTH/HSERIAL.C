char* SERIAL =


"SERIALOPEN "
"Stack: (n1 n2 n3 n4 --- addr1 addr2 n5 )"
"Usage: This is the primitive used to opening a serial port:"
"          - <n1> is the base IO address (3f8, 2f8, ...)"
"          - <n2> is the irq number (4, 3, 9, ...)"
"          - <addr1> and <n3> are buffer address and size for input"
"          - <addr2> and <n4> are buffer address and size for output"
"          - <n5> is the channel nb, to be used with other serial functions"
"            (SerialClose, SerialIn, SerialOut, ...)"
" Note: This is the definition which allocate space for buffers, not you."
"  See: SerialClose AbortSerial SerialIn ..."
""
"About serial communications under FROTH:"
"    Serial communications is made under interrupt (in and out). So, for"
"    output, you must call SERIALFLUSHOUT to be sure that data is sent."
"    For input, you have the powerful possibility to receive data by"
"    'packet', not only by character. For example, if you tell that a"
"    packet can be sended on character CR (0Dh), you can receive the"
"    all packet, not character by character. You can define up to 10"
"    packet definitions, each one can be made from 1 to 4 characters."
"    If you get data by packet, you must not use SERIALIN and SERIALIN?"
"    definitions."
""
"WARNING: Serial definitions are not yet coded in this version."


"NONEPARITY "
"Stack: ( --- 0 )"
"Usage: Constant, to be used with SERIALPARAM, which has the meaning: no parity."
"  See: SerialParam"


"ODDPARITY "
"Stack: ( --- 1 )"
"Usage: Constant, to be used with SERIALPARAM, which has the meaning: odd parity."
"  See: SerialParam"


"EVENPARITY "
"Stack: ( --- 2 )"
"Usage: Constant, to be used with SERIALPARAM, which has the meaning: even parity."
"  See: SerialParam"


"SerialParam "
"Stack: ( n1 n2 n3 n4 n5 n6 --- )"
"Usage: Parameter an opened serial channel:"
"         - <n1> is the serial channel (as returned by SERIALOPEN)"
"         - <n2> is the bauds speed (1200, 2400, ...)"
"         - <n3> is the parity (use constants NONEPARITY, ODDPARITY and EVENPARITY)"
"         - <n4> is the nb of data bits (7 or 8)"
"         - <n5> is the nb of start bits (0, 1 or 2)"
"         - <n6> is the nb of stop bits (0, 1 or 2)"
"  See: SerialOpen NONEPARITY ODDPARITY EVENPARITY"


"SerialDefPacket "
"Stack: ( n1 n2 n3 n4 n5 n6 --- )"
"Usage: Define the characters which define a packet:"
"         - <n1> is the serial channel"
"         - <n2> is the packet nb (from 0 to 9)"
"         - <n3> to <n6> are the characters which define the packet. Use value 0"
"           if not used."
"  See: SerialOpen SerialPackets? SerialReadPacket"


"SerialPackets? "
"Stack: ( n1 addr n2 --- n3 )"
"Usage: Return the number of packets available on input. They must be read"
"       with the definition SERIALPACKETREAD>"
"  See: SerialDefPacket SerialPacketRead"


"SerialPacketRead "
"Stack: ( n1 addr n2 --- n3 n4 )"
"Usage: Read next packet from serial channel <n1>. Packet is stored starting"
"       at address <addr>. No more than <n2> characters are written to memory"
"       (others are discarded). <n3> is the number of the packet (from 0 to 9)."
"       <n4> is the number of characters read (written)"
"       to memory)."
"  See: SerialOpen SerialDefPacket SerialPackets?"


"SerialClose "
"Stack: ( n --- )"
"Usage: Close an opened serial channel."
"  See: SerialOpen SerialAbort"


"SerialIn "
"Stack: ( n --- c )"
"Usage: Read next character from serial channel <n>."
"       This word waits until one char is available (if no"
"       error), and YIELDing is done (threads)."
"  See: SerialOpen SerialIn? SerialFlushIn"


"SerialIn? "
"Stack: ( n1 --- n2 )"
"Usage: Return the number <n2> of characters available on input on channel <n1>."
"  See: SerialOpen SerialIn SerialFlushIn"


"SerialRead "
"Stack: ( n1 addr n2 --- n3 )"
"Usage: Read <n2> characters from serial channel <n1>, stored starting at"
"       address <addr>. The number of read characters is returned as <n3>, or"
"       -1 if error. This word waits until <n2> chars are available (if no"
"       error), and YIELDing is done (threads)."
"  See: SerialOpen SerialIn? SerialFlushIn"


"SerialFlushIn "
"Stack: ( n --- )"
"Usage: Flush (discard) all characters pending on input on channel <n>."
"  See: SerialOpen SerialIn? SerialIn SerialRead SerialPacketsNb SerialPacketRead"


"SerialOut "
"Stack: ( n c --- )"
"Usage: Send character <c> to opened serial channel <n>."
"  See: SerialOpen SerialWrite SerialFlushOut"


"SerialWrite "
"Stack: ( n1 addr n2 --- )"
"Usage: Send <n2> characters, starting at address <addr> to opened serial"
"       channel <n1>. Characters are then sent by interrupt, so use"
"       SERIALFLUSHOUT to control emission."
"  See: SerialOpen SerialOut SerialFlushOut"


"SerialFlushOut "
"Stack: ( n --- )"
"Usage: Wait until all output pending characters on serial channel <n> are"
"       sent. Yield (threads) is made until control is given back to caller"
"       definition."
"  See: SerialOpen SerialOut SerialWrite"


"SerialAbort "
"Stack: ( n --- )"
"Usage: Stop serial interrupt <n>. This definition is to be used only within"
"       load file, before you forget definitions which use SERIALOPEN. If you"
"       do not abort serial, you will forget (remove from memory) buffers"
"       where input and output data are stored, then a crash will occur."
"       You cannot use SERIALCLOSE because serial channel is unknow at this"
"       time."
"  See: SerialOpen SerialClose"



""
;
