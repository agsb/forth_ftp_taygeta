char* LOCVAR =


"1LOC "
"  Stack: ( --- )"
"  Usage: Allocate space for one (1LOC) to four (4LOC) local variables."
"    See: @0 to @3  !0 to !3  +!0 to +!1  LOOP0 to LOOP3"
"Example: : test"
"           2LOC 4 !0  10 !1"
"           BEGIN"
"               @0 . ', emit @1 . space"
"               5 +!1"
"           LOOP0 ;"
"        gives: 4,10 3,15 2,20 1,25"

"2LOC 1LOC"
"3LOC 1LOC"
"4LOC 1LOC"


"@0 "
"  Stack: ( --- n )"
"  Usage: Get the value of a local variable."
"    See: 1LOC to 4LOC  !0 to !3  +!0 to +!1  LOOP0 to LOOP3"
"Example: see 1LOC"

"@1 @0"
"@2 @0"
"@3 @0"


"!0 "
"  Stack: ( n --- )"
"  Usage: Store the value of a local variable."
"    See: 1LOC to 4LOC  @0 to @3  +!0 to +!1  LOOP0 to LOOP3"
"Example: see 1LOC"

"!1 !0"
"!2 !0"
"!3 !0"


"+!0 "
"  Stack: ( n --- )"
"  Usage: Increment by <n> the value of a local variable."
"    See: 1LOC to 4LOC  @0 to @3  !0 to !1  LOOP0 to LOOP3"
"Example: see 1LOC"

"+!1 +!0"
"+!2 +!0"
"+!3 +!0"


"LOOP0 "
"  Stack: ( --- )"
"  Usage: Decrement by 1 the value of a local variable and jump if non zero"
"         back to the balanced BEGIN."
"    See: 1LOC to 4LOC  @0 to @3  !0 to !1  +!0 to +!3"
"Example: see 1LOC"

"LOOP1 LOOP0"
"LOOP2 LOOP0"
"LOOP3 LOOP0"


""
;

