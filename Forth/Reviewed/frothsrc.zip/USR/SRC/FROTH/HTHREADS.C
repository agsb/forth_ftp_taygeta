char* THREADS =


"MAXNBTHREADS "
"Stack: ( --- n )"
"Usage: This constant gives the maximum number of threads that can be run under"
"       this current version of FROTH."
"  See: MaxNbThreads ActiveThread NewThread EndThread KillThread Yield"
"Definition: A thread is a section of program in execution. Each thread have"
"            to decide when to leave the running state to become in waiting"
"            state. Then, an other active threaded continue to run."


"NBTHREADS "
"Stack: ( --- n )"
"Usage: Give the number of active threads, which actually run. The minimal"
"       number is of course 1. The maximal is 'MaxNbThreads'."
"  See: MaxNbThreads ActiveThread NewThread EndThread KillThread Yield"
"Thread definition : type 'USE MaxNbThreads'"


"ACTIVETHREAD "
"Stack: ( --- n )"
"Usage: Give the number of the current active thread. This is a number between"
"       0 and 'MaxNbThreads' - 1."
"  See: MaxNbThreads NbThreads NewThread EndThread KillThread Yield"
"Thread definition : type 'USE MaxNbThreads'"


"NEWTHREAD "
"       Stack: ( n --- )"
"Input stream: n NewThread name"
"       Usage: Creation of a new thread. An existing word name must be given."
"              This new thread will be executed ONLY when the thread which"
"              created this one will yield. Each thread has its own parameters"
"              stack. But, when create it, you can copy <n> values from the stack"
"              of the current thread to the newly thread. If no copy is wanted,"
"              <0> is a legal value."
"       Flags: This is an immediate word."
"         See: MaxNbThreads NbThreads ActiveThread EndThread KillThread Yield"
"Thread definition : type 'USE MaxNbThreads'"


"ENDTHREAD "
"Stack: ( --- )"
"Usage: End the current active thread. The thread #0 cannot be ended. This word"
"       is used by the thread itself to terminate itself."
"  See: MaxNbThreads NbThreads ActiveThread NewThread KillThread Yield"
"Thread definition : type 'USE MaxNbThreads'"


"KILLTHREAD "
"Stack: ( n1 --- n2 )"
"Usage: End a given active thread. The thread #0 cannot be ended. This word"
"       is used by any thread to terminate any other thread. A status is"
"       returned:"
"          -  0 means ok, thread was killed;"
"          - -1 means that thread #0 can't be killed;"
"          - -2 means that that the n is out of range;"
"          - -3 means that the n-th thread is not active."
"  See: MaxNbThreads NbThreads ActiveThread NewThread EndThread Yield"
"Thread definition : type 'USE MaxNbThreads'"


"YIELD "
"Stack: ( --- )"
"Usage: Give control to other(s) thread(s), if any. If there is an other active"
"       thread, the thread which called 'Yield' loose cpu control."
" Note: Some I/O words call YIELD. For example, KEY which wait until a key from"
"       the keyboard is available, calls YIELD while no key is available."
"  See: MaxNbThreads NbThreads ActiveThread NewThread EndThread KillThread  Key"
"Thread definition : type 'USE MaxNbThreads'"


""
;
