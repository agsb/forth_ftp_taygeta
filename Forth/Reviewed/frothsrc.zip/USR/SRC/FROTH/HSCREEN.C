char* SCREEN =


"SETVIDEOMODE "
"Stack: ( n --- )"
"Usage: Select the given video mode. See your VGA card manual to see values."
"       Value 3 is 25x80, text mode. On a PARADISE super VGA card, value 84 is"
"       43x132, text mode. The constants #ROWS and #COLS are updated to give"
"       the number of rows and columns."
"  See: #Rows #Cols #Pages GetVideoMode"


"GETVIDEOMODE "
"Stack: ( --- n )"
"Usage: Return the value of the current video mode. See the description of the"
"       word 'SetVideoMode'."
"  See: #Rows #Cols #pages SetVideoMode"


"#PAGES "
"Stack: ( --- n )"
"Usage: Return the number of video pages of the current text screen."
"       This is a constant updated by the word 'SetVideoMode'."
"  See: #rows #cols SetVideoMode"


"PAGE# "
"Stack: ( --- addr )"
"Usage: Variable which contains the current video page."
"  See: page> >page #pages"


"#ROWS "
"Stack: ( --- n )"
"Usage: Return the number of rows of the current text screen. The 'normal' value"
"       is 25, but can change depending the current video mode. This is a"
"       constant updated by the word 'SetVideoMode'."
"  See: #Cols #pages SetVideoMode"


"#COLS "
"Stack: ( --- n )"
"Usage: Return the number of columns of the current text screen. The 'normal'"
"       value is 80, but can change depending the current video mode. This is a"
"       constant updated by the word 'SetVideoMode'."
"  See: #Rows #pages SetVideoMode"


"PAGE> "
"Stack: ( --- )"
"Usage: Select the current video page, as fixed in the variable 'page#'."
"       The number of available video pages is stored in the constant '#pages'."
"  See: SetVideoMode GetVideoMode #pages page# >page"


">PAGE "
"Stack: ( n --- )"
"Usage: Select a given video page."
"       The number of available video pages is stored in the constant '#pages'."
"  See: SetVideoMode GetVideoMode #pages page#"


"GOTOXY "
"Stack: ( x y --- )"
"Usage: Put the cursor to the position column x, row y. The values start from 0."
"       No control is made to see is values are out of limit."
"  See: WhereXY WhereX WhereY #Rows #Cols"


"GOTOX "
"Stack: ( n --- )"
"Usage: Put the cursor to the given column n, on current row. Value start from"
"       0. No control is made to see is value is out of limit."
"  See: WhereXY WhereX WhereY GotoXY GotoY #Rows #Cols"


"GOTOY "
"Stack: ( n --- )"
"Usage: Put the cursor to the given row n, on current column. Value start from"
"       0. No control is made to see is value is out of limit."
"  See: WhereXY WhereX WhereY GotoXY GotoX #Rows #Cols"


"WHEREXY "
"Stack: ( --- x y )"
"Usage: Return the actual cursor position: x is the column, y the row. Values"
"       start from 0."
"  See: GotoXY WhereX WhereY #Rows #Cols"


"WHEREX "
"Stack: ( --- n )"
"Usage: Return the actual column cursor position. Values start from 0."
"  See: GotoXY WhereXY WhereY #Rows #Cols"


"WHEREY "
"Stack: ( --- n )"
"Usage: Return the actual row cursor position. Values start from 0."
"  See: GotoXY WhereXY WhereX #Rows #Cols"


"BACKFOREGROUND "
"Stack: ( n1 n2 --- n3 )"
"Usage: Transform a background color (n1) and a foreground color (n2) into an"
"       'attribute', ready to be used in fonctions like !XY or !SCREEN."
"       n3 = (n1 << 4) + n2"


"SCREENBACKGROUND "
"Stack: ( --- addr )"
"Usage: The value of this variable is used implicitly as attribute by the"
"       next words:"
"       cls clrline clreol !xychar !xynchar !xystring !string"
"  See: these words and: BackForeGround"


"?UpdateCursor "
"Stack: ( --- addr )"
"Usage: The value of this variable is used in the next words:"
"       !string !astring !xystring !xyastring"
"       If set to TRUE, cursor position id updated after drawing. Else not."
"  See: these words and: whereX whereY whereXY"


"CURSOR "
"Stack: ( n --- )"
"Usage: Change the cursor shape:"
"          - n=0 means no cursor visible"
"          - n=1 means a blinking dash under characters"
"          - n=2 means a blinking plain cursor"
"  See: gotoxy gotox gotoy wherex wherey wherexy"


"@xychar "
"Stack: ( x y --- c )"
"Usage: Return the character stored on screen at (x-column, y-row)."
"  See: @xyachar !xychar !xyachar !xynchar !xynachar"


"@xyachar "
"Stack: ( x y --- a c )"
"Usage: Return the character stored on screen at (x-column, y-row),"
"       and the color/attribute of this character."
"  See: @xychar !xychar !xyachar !xynchar !xynachar"


"!xychar "
"Stack: ( x y c --- )"
"Usage: Write the character <c> at position (x-column, y-row), with implicite"
"       color/attribute (variable ScreenBakGround)."
"  See: ScreenBackGround BackForeGround !xyachar !xynchar !xynachar"


"!xyachar "
"Stack: ( x y a c --- )"
"Usage: Write the character <c> at position (x-column, y-row), with explicite"
"       color/attribute <a>."
"  See: BackForeGround !xychar !xynchar !xynachar"


"!xynchar "
"Stack: ( x y n c --- )"
"Usage: Write n characters <c> starting at position (x-column, y-row), with implicite"
"       color/attribute (variable ScreenBakGround)."
"  See: ScreenBackGround BackForeGround !xychar !xyachar !xynachar"


"!xynachar "
"Stack: ( x y n a c --- )"
"Usage: Write n characters <c> starting at position (x-column, y-row), with explicite"
"       color/attribute <a>."
"  See: BackForeGround !xychar !xynchar !xyachar"


"!string "
"Stack: ( addrz --- )"
"Usage: Write the given string starting at address <addrz> at current cursor"
"       position. The value of variable ScreenBackground is used as implicit"
"       color/attribute. Update cursor positions is made only if variable"
"       ?UpdateCursor is set to TRUE."
"  See: ScreenBackGround BackForeGround ?UpdateCursor !astring !xystring !xyastring"


"!astring "
"Stack: ( a addrz --- )"
"Usage: Write the given string starting at address <addrz> at current cursor"
"       position, with explicit color/attribute value <a>. Update cursor"
"       positions is made only if variable ?UpdateCursor is set to TRUE."
"  See: ScreenBackGround BackForeGround ?UpdateCursor !string !xystring !xyastring"


"!xystring "
"Stack: ( x y addrz --- )"
"Usage: Write the given string starting at address <addrz> at given cursor"
"       position (x-column, y-row). The value of variable ScreenBackground"
"       is used as implicit color/attribute. Update cursor positions is made"
"       only if variable ?UpdateCursor is set to TRUE."
"  See: ScreenBackGround BackForeGround ?UpdateCursor !string !astring !xyastring"


"!xyastring "
"Stack: ( x y a addrz --- )"
"Usage: Write the given string starting at address <addrz> at given cursor"
"       position (x-column, y-row), with explicit color/attribute value <a>. Update cursor"
"       positions is made only if variable ?UpdateCursor is set to TRUE."
"  See: ScreenBackGround BackForeGround ?UpdateCursor !string !astring !xystring"


"!xylstring "
">XYLSTRING_CHAR stack: ( c --- )"
">XYLSTRING_ATTR stack: ( n1 n2 n3 --- )   n1:0-7 n2:background n3:foreground"
"!XYLSTRING      stack: ( x y addrz --- )"
"Usage: !XYLSTRING write the given string starting at address <addrz> at given cursor"
"       position (x-column, y-row). Attributes are given inside the string, according"
"       to delimitater character set with >XYLSTRING_CHAR and attributes/colors set with"
"	 >XYLSTRING_ATTR. Update cursor positions is made only if variable ?UpdateCursor is set to TRUE."
"Example:"
"    '~ >xylstring"
"    0 black  red  0 >xylstring_attr"
"    0 yellow blue 1 >xylstring_attr"
"    \"~{0}background black, foreground red~{1}background yellow, foreground blue\""

">xylstring_char xylstring"
">xylstring_attr xylstring"


"cls "
"Stack: ( --- )"
"Usage: Clear all the screen. The value of variable ScreenBackground"
"       is used as implicit color/attribute. The cursor is set to (0, 0)."
"  See: ScreenBackGround BackForeGround AttrCls clrline aclrline clreol aclreol"


"attrcls "
"Stack: ( a --- )"
"Usage: Clear all the screen, with given explicite color/attribute <a>. The cursor is set to (0, 0)."
"  See: BackForeGround cls clrline aclrline clreol aclreol"


"clrline "
"Stack: ( y --- )"
"Usage: Clear the entire given line <y>. The value of variable ScreenBackground"
"       is used as implicit color/attribute. The cursor position does not change."
"  See: ScreenBackGround BackForeGround cls AttrCls aclrline clreol aclreol"


"aclrline "
"Stack: ( a y --- )"
"Usage: Clear the entire given line <y>. The value <a>"
"       is used as explicit color/attribute. The cursor position does not change."
"  See: BackForeGround cls AttrCls clrline clreol aclreol"


"clreol "
"Stack: ( --- )"
"Usage: Clear current line, from current position, to end of line. The value"
"       of variable ScreenBackground is used as implicit color/attribute."
"       The cursor position does not change."
"  See: ScreenBackGround BackForeGround cls AttrCls clrline aclrline aclreol"


"aclreol "
"Stack: ( a --- )"
"Usage: Clear current line, from current position, to end of line. The value"
"       <a> is used as explicit color/attribute."
"       The cursor position does not change."
"  See: BackForeGround cls AttrCls clrline aclrline clreol"


"BLACK "
"Stack: ( --- 0 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"BLUE "
"Stack: ( --- 1 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"GREEN "
"Stack: ( --- 2 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"CYAN "
"Stack: ( --- 3 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"RED "
"Stack: ( --- 4 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"MAGENTA "
"Stack: ( --- 5 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"BROWN "
"Stack: ( --- 6 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTGRAY "
"Stack: ( --- 7 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"DARKGRAY "
"Stack: ( --- 8 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTBLUE "
"Stack: ( --- 9 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTGREEN "
"Stack: ( --- 10 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTCYAN "
"Stack: ( --- 11 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTRED "
"Stack: ( --- 12 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"LIGHTMAGENTA "
"Stack: ( --- 13 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"YELLOW "
"Stack: ( --- 14 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


"WHITE "
"Stack: ( --- 15 )"
"Usage: Push on stack the constant value of this color."
"  See: BLACK BLUE GREEN CYAN RED MAGENTA BROWN LIGHTGRAY DARKGRAY LIGHTBLUE"
"       LIGHTGREEN LIGHTCYAN LIGHTRED LIGHTMAGENTA YELLOW WHITE BackForeGround"


""
;
