char* PORTIO =


"IN "
"Stack: ( n --- u )"
"Usage: Read dword value from port <n>."
"  See: OUT  CIN COUT  WIN WOUT"


"CIN "
"Stack: ( n --- uw )"
"Usage: Read byte value from port <n>."
"  See: IN OUT  COUT  WIN WOUT"


"WIN "
"Stack: ( n --- ub )"
"Usage: Read word value from port <n>."
"  See: IN OUT  CIN COUT  WOUT"


"OUT "
"Stack: ( u n --- )"
"Usage: Write dword value <u> to port <n>."
"  See: IN  CIN COUT  WIN WOUT"


"COUT "
"Stack: ( ub n --- )"
"Usage: Write byte <ub> to port <n>."
"  See: IN OUT  CIN  WIN WOUT"


"WOUT "
"Stack: ( uw n --- )"
"Usage: Write word value <uw> to port <n>."
"  See: IN OUT  CIN COUT  WIN"



""
;
