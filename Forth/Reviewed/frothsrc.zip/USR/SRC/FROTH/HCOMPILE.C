char* COMPILER =


"VOCABULARY "
"Input stream: VOCABULARY definition"
"       Usage: Into the dictionnary, definitions are stored into vocabularies."
"              These vocabularies have (like MS/DOS directories) arborescent"
"              organization. The context vocabulary is the one where searching"
"              definitions is made. The current vocabulary is the one where new"
"              definitions are added. VOCABULARY is used to create a new"
"              vocabulary definition. When called, this definition will bring"
"              this vocabulary as the context vocabulary. This definition (created"
"              with VOCABULARY) is an immediate word. The rules which are"
"              applied to find a definition are:"
"                 - above:      all levels (father, father's, ...) until the root vocbulary is reached."
"                 - same level: all brothers."
"                 - below:      the sons of the vocabulary, just one level below."
"    See also: CURRENT VOCS WORDS XWORDS"


"CURRENT "
"Stack: ( --- )"
"Usage: Calling CURRENT set the context vocabulary as current (the one where"
"       new definitions are linked). Call VOCS to see which vocabulary is"
"       context and which is context."
"  See: VOCABULARY VOCS WORDS XWORDS"


"VOCS "
"Stack: ( --- )"
"Usage: Show all vocabularies defined, and which one is the context, and which"
"       one is the current."
"  See: VOCABULARY CURRENT WORDS XWORDS"


"XWORDS "
"Stack: ( --- )"
"Usage: Show all user definitions recorded into the dictionnary, starting"
"       at context vocabulary."
"  See: VOCABULARY CURRENT WORDS  : ;  FORGET"


"WORDS "
"Stack: ( --- )"
"Usage: Show all definitions (user and system) recorded into the dictionnary, starting"
"       at context vocabulary."
"  See: VOCABULARY CURRENT XWORDS  : ;  FORGET"


"\\ "
"Input stream: \\ comments"
"       Usage: Start a comment, until the end of line."
"    See also: ( )"


"( "
"Input stream: ( comments )"
"       Usage: ( starts a comment section. ) ends the comment section."
"              ( and ) are nestable, and are not limited not a line."
"    See also: \\"

") ( "


": "
"Input stream: : definition ... ;"
"       Usage: : (colon) is used to define a colon-definition. The system"
"              enters into compile-state: each next definition or number"
"              parsed is then compiled into the definition under creation,"
"              instead to be executed."
"              ; (semicolon) is used to end the definition, and then to"
"              return to execute-state."
"    See also: VOCABULARY VOCS WORDS XWORDS ?REDEFINITIONS"

"; : "


"[ "
"Stack: ( --- addr )"
"Usage: While compiling a colon-definition, switch from compile-mode to"
"       immediate-mode."
"  See: : ]"


"] "
"Stack: ( --- addr )"
"Usage: Return to compile a colon-definition, switch from immediate-mode to"
"       compile-mode."
"  See: : ["


"FORGET "
"Input stream: FORGET definition"
"       Usage: This word is used to remove definitions from dictionnary."
"              All definitions defined bewteen the one given and the last defined"
"              into the dictionnary are forgotten. Why forget words ? Because"
"              you want to redefine them (remember that redefinitions are not"
"              allowed in FROTH). If the definition given to FORGET does not"
"              exist, nothing happens. When forgetting definitions, FROTH take"
"              care to give back all data used by these words (and DUST, the"
"              garbage collector is automatically called)."
"    See also: : ; CURRENT VOCABULARY WORDS XWORDS VOCS"


"?SPEED "
"Stack: ( --- addr )"
"Usage: This variable is interpreted by FROTH compiler when generating code."
"       If set to TRUE (default), compiler will privilegiate speed agains"
"       space."
"  See: ?SAFE ?ENOUGHT ?OPTIMIZE ?IARITHOVERFLOW : ;  @ ! TRUE FALSE"


"?OPTIMIZE "
"Stack: ( --- addr )"
"Usage: This variable is interpreted by FROTH compiler when generating code."
"       If set to TRUE (default), compiler try to optimize the code by"
"       looking backward."
"  See: ?SAFE ?ENOUGHT ?OPTIMIZE ?IARITHOVERFLOW : ;  @ ! TRUE FALSE"


"?IARITHOVERFLOW "
"Stack: ( --- addr )"
"Usage: This variable is interpreted by FROTH compiler when generating code."
"       If set to TRUE (default), compiler generate code to make an exception"
"       on integer arithmetic overflow (+ - * ...)"
"  See: ?SAFE ?OPTIMIZE ?ENOUGHT : ;  @ ! TRUE FALSE  + - *"


"?OK "
"Stack: ( --- addr )"
"Usage: When set to FALSE (default), this variable means that froth interpret"
"       print the number of integers on stack, else just 'ok '."
"  See: ?CHAT"


"?CHAT "
"Stack: ( --- addr )"
"Usage: When set to TRUE (default, this variable means that froth interpret"
"       is chat: he prints a . (dot) every time a new word is defined."
"  See: ?OK"


"?SAFE "
"Stack: ( --- addr )"
"Usage: This variable is interpreted by FROTH compiler when genarting code."
"       If set to TRUE:"
"          - MACROS definitions will test the right number of arguments;"
"          - ?ENOUGHT is compiled."
"       If set to FALSE:"
"          - MACROS definitions will not test the right number of arguments;"
"          - ?ENOUGHT is not compiled and previous number compiled is removed."
" Note: In any case, not macro definitions will always test the right"
"       number of arguments."
"  See: ?SPEED ?ENOUGHT ?OPTIMIZE ?IARITHOVERFLOW : ;  @ !  FALSE TRUE"


"?ENOUGHT ?SAFE "


"?REDEFINITIONS "
"Stack: ( --- addr )"
"Usage: If set to TRUE, redefinitions are allowed."
"  See: :"


"INFOS "
"Stack: ( --- )"
"Usage: Show informations about code size and date size> It is a good idea"
"       to put INFOS at the end of the file loaded: after compilation, wou will"
"       see how munch code and static data."


"WINF "
"Input stream: winf definition"
"       Usage: Show various informations about the given definition (size,"
"              cross-ref calls, attributes, ...)."
" Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"\"LOAD "
"Stack: ( addrz --- )"
"Usage: Start the interpretation of the given text file. If extension is not"
"       given, then .FTH is added. \"LOAD will be used to 'include' anothers"
"       files within one loaded. \"LOAD are nestable (see LIMITS)."
"  See: LOAD LIMITS"


"LOAD "
"Stack: ( --- )"
"Usage: Start the interpretation of the first file edited within FROSTED (in"
"       buffer #1)."
"  See: \"LOAD ED"
" Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"FROTH "
"Stack: ( --- )"
"Usage: Set the context vocabulary to the FROTH vocabulary. This vocabulary"
"       contains base definitions (compiler, memory, arithmetic, logical, ...)."
"       This is an immediate word (as each definition created by VOCABULARY)."
"  See: VOCABULARY CURRENT VOCS WORDS XWORDS"


"QUIT "
"Stack: ( --- )"
"Usage: Exit 'application' and returns to external FROTH interpret. Stack is"
"       not emptied."


"\"ERROR "
"Stack: ( addrz --- )"
"Usage: Exit (as error) with a given error message. This word is useful for"
"       run-time checking (array bounds for example)."
"  See: WORDNAME$"


"WORDNAME$ "
"Stack: ( --- addrz )"
"Usage: Return the name of the calling definition. This word should not be"
"       called from a turnkey application."
"  See: \"ERROR"


"WORDSIZE "
"Stack: ( --- n )"
"Usage: Return the size of machine-word (4 on 386-486)."
"  See: WORDSIZE+ WORDSIZE- WORDSIZE* WORDSIZE/"


"?LOAD "
"Stack: ( --- )"
"Usage: Error if system is currently loading file."


"?COMPILE "
"Stack: ( --- )"
"Usage: Error is system is not currently in compile-mode."


"?EXECUTE "
"Stack: ( --- )"
"Usage: Error is system is not currently in execute-mode."


"[: "
"Stack: ( --- )"
"Usage: The word [:, only callable in compile-mode, allows to specify after"
"       it hexadecimals 386 code operations. This mode is closed with :]."

":] [:"


"IMMEDIATE "
"Stack: ( --- )"
"Usage: Called inside a colon-definition, marks this one as an immediate-word."
"  See: : ; WINF"


"COMPILE "
"       Stack: ( --- )"
"Input stream: COMPILE immediate_word"
"       Usage: Compile next immediate word into current colon-definition."


"' "
"       Stack: ( --- addr )"
"Input stream: ' word"
"       Usage: Parse next word (must be defined). If exeute-state, push"
"              code-address of the word on stack. If Compile-state, this"
"              will be done at run-time."
"        Note: The code-address is used with EXECUTE definition to"
"              allow execution of the given word"
"  See: EXECUTE  WINF"


"EXECUTE "
"Stack: ( addr --- )"
"Usage: Execute the code given at <addr>."
" Note: The code-address is usualy given by the word ' (tick)"
"  See: '  WINF"


"DYNAMIC "
"Input stream: DYNAMIC variable"
"       Usage: Create a dynamic 'variable' (remember: a variable is a word created"
"             by a defining-word. Space for this variable will then ALLOCated and FREEd."
"         See: BUILD> ALLOT DOES>  ALLOC FREE"
""
"Example: dynamic constant myConst"
"*** See manual for in depth discussion ***"


"ALLOC "
"Input stream: ALLOC dynamic_variable"
"       Usage: Allocate data space for the next given dynamic variable."
"         See: BUILD> ALLOT DOES>  DYNAMIC FREE"
"*** See manual for in depth discussion ***"


"FREE "
"Input stream: FREE dynamic_variable"
"       Usage: Free data space for the next given dynamic variable."
"         See: BUILD> ALLOT DOES>  DYNAMIC ALLOC"
"*** See manual for in depth discussion ***"


"AllotMore "
"Stack: ( n --- )"
"Usage: Allocate more space for the last word created with a defining-word."
"  See: BUILD> ALLOT DOES>"
"*** See manual for in depth discussion ***"

"BAllotMore AllotMore"
"WAllotMore AllotMore"


"BUILD> "
"Usage: The word BUILD>is used inside a defining-word: at run-time of the defining-word,"
"       it creates a new definition into dictionnary. Further execution of this"
"       definition will push on stack data allocated by ALLOT, then execute words"
"       defined after DOES>."
" Note: The three words BUILD> ALLOT and DOES> are always used in the same order."
"*** See manual for in depth discussion ***"

"ALLOT BUILD>"
"BALLOT BUILD>"
"WALLOT BUILD>"
"DOES> BUILD>"
"CREATE BUILD>"


"SAVE.EXE "
"Stack: ( addrz --- n )"
"Usage: Build a stand-alone application (.EXE file). The top defined word will"
"       run after .EXE load. <addrz> is a pointer to filename (you must add .EXE"
"       extension by yourself). <n> is either -1 on error disk, either the size of"
"       the built .exe file)."
"     See: ?TURNKEY ?FROTHTURNKEY"


"?FROTHTURNKEY "
"Stack: ( --- f )"
"Usage: Return the true flag is we are running the turnkey edition of"
"       FROTH (i.e. FROTHT.EXE)."
"  See: SAVE.EXE ?TURNKEY"


"{ "
"Input stream: { infixed expression }"
"       Usage: { (left brace) open the infixed mode: expression until } (right brace)"
"              is interpreted as an infixed expression and then compiled as postfixed."
"     Example:"
"               : myDef"
"                 integer x  integer y  integer z"
"                 10 y !  20 z !"
"                 { ( y + z ) * ( y - z ) }"
"                 x ! ;"
"              The last line is compiled as:"
"                 y z + y z - *"
"Important note: Each word of the infixed expression must be separated by"
"                a space."
"WARNING! This feature will only be available in the release."

"} {"


"STRUCT "
" *** Not still implemented ***"

"ENDSTRUCT STRUCT"


"CONST "
"   Stack (compile time): ( n --- )"
"       Stack (run time): ( --- n )"
"   Usage: Create an integer constant."
"     See: ICONST INT  BUILD> ALLOT DOES>"
"Examples: [1] 10 constant ten"
"          [2] : test"
"                1000 100 * const big"
"                big . ;"
"  Remark: CONST and CONSTANT are the same."

"CONSTANT CONST"


"INT "
"   Stack (compile time): ( --- )"
"       Stack (run time): ( --- addr )"
"   Usage: Create an integer variable."
"     See: CONST IINT  @ !  BUILD> ALLOT DOES>"
"Examples: [1] int myInt"
"              100 myInt !"
"              myInt @ ."
"          [2] : test"
"                variable myInt"
"                1000 100 * myInt !"
"                myInt @ . ;"
"  Remark: INT and VARIABLE are the same."
"    Note: If you want to create integer variable with an initial value,"
"          then use IINT instead INT."

"VARIABLE INT"
"INTEGER INT"


"IINT "
"   Stack (compile time): ( n --- )"
"       Stack (run time): ( --- addr )"
"   Usage: Create an integer variable with an initial value."
"     See: CONST INT  @ !  BUILD> ALLOT DOES>"
"Examples: [1] 100 int myInt"
"              myInt @ ."
"          [2] : test"
"                1000 100 * iint myInt"
"                myInt @ . ;"
"  Remark: INT and VARIABLE are the same."
"    Note: If you do not want to create integer variable with an initial"
"          value, then use INT instead IINT."

"IINTEGER IINT"


"LOGICAL "
"   Stack (compile time): ( --- )"
"       Stack (run time): ( --- addr )"
"  Usage: Create a logical (boolean) variable. A logical variable can"
"         only be set to 0 (false) and 1 (true)."
"    See: ILOGICAL  C@ C!  FALSE! TRUE! FALSE? TRUE?"
"Example: logical myFlag"
"         myFlag false!"
"   Note: If you want to create logical variable with an initial value,"
"         then use ILOGICAL instead LOGICAL."


"ILOGICAL "
"   Stack (compile time): ( f --- )"
"       Stack (run time): ( --- addr )"
"  Usage: Create a logical (boolean) variable with an initial value. A"
"         logical variable can only be set to 0 (false) and 1 (true)."
"    See: LOGICAL  C@ C!  FALSE! TRUE! FALSE? TRUE?"
"Example: logical myFlag"
"         myFlag false!"
"   Note: If you do not want to create logical variable with an initial"
"         value, then use LOGICAL instead ILOGICAL."


"FALSE! "
"  Stack: ( addr --- )"
"  Usage: Store the logical false value (0) into the logical (boolean)"
"         variable given (addr)."
"    See: LOGICAL ILOGICAL  C@ C!  TRUE! FALSE? TRUE?"
"Example: logical myFlag"
"         myFlag false!"
"   Note: FALSE! is the same as: 0 C!"
"                     or better: FALSE C!"


"TRUE! "
"  Stack: ( addr --- )"
"  Usage: Store the logical true value (1) into the logical (boolean)"
"         variable given (addr)."
"    See: LOGICAL ILOGICAL  C@ C!  FALSE! FALSE? TRUE?"
"Example: logical myFlag"
"         myFlag true!"
"   Note: FALSE! is the same as: 1 C!"
"                     or better: TRUE C!"


"FALSE? "
"  Stack: ( addr --- f )"
"  Usage: Test for the logical false value (0) from the logical (boolean)"
"         variable given (addr)."
"    See: LOGICAL ILOGICAL  C@ C!  FALSE! TRUE! TRUE?"
"Example: logical myFlag"
"         myFlag false!"
"         : test"
"           myFlag? if .\" not true\" else .\" true\" ;"
"   Note: FALSE? is the same as: C@ 0 =="
"                     or better: C@ FALSE =="


"TRUE? "
"  Stack: ( addr --- f )"
"  Usage: Test for the logical true value (1) from the logical (boolean)"
"         variable given (addr)."
"    See: LOGICAL ILOGICAL  C@ C!  FALSE! TRUE! FALSE?"
"Example: : test"
"           logical myFlag"
"           myFlag true!"
"           myFlag? if .\" not true\" else .\" true\" ;"
"   Note: TRUE? is the same as: C@ 1 =="
"                    or better: C@ TRUE =="


"#IF "
"  Stack: ( f --- )"
"  Usage: #IF is used in execute or compile state to compile a given part"
"         (up to next #ELSE or #ENDIF) of popped flag is true. #IF #ELSE"
"         and #ENDIF are nestable (think to the C preprocessor #IF)."
"  Alias: [if]    same as  #if"
"         [else]  same as  #else"
"         [then]  same as  #endif"

"#ELSE #IF"
"#ENDIF #IF"
"[IF] #IF"
"[ELSE] #IF"
"[THEN] #IF"


""
;
