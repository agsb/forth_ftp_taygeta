char* TRACE =


".S "
"Stack: ( --- )"
"Usage: Show all integers available on stack."


"TRACE_CLEAR "
"Stack: ( --- )"
"Usage: Clear all messages previously sent by application to trace manager."
"  See: TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_BEGIN "
"Stack: ( --- )"
"Usage: Start a message, to be sent to the trace manager. Use after: TRACE_. TRACE_.S and TRACE_TYPE."
"  See: TRACE_CLEAR TRACE_END TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_END "
"Stack: ( --- )"
"Usage: Send now the message built to the trace manager."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_. "
"Stack: ( n --- )"
"Usage: Add to the current message (under construction) the value on top stack integer."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_TYPE TRACE_.S TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_TYPE "
"Stack: ( addrz --- )"
"Usage: Add to the current message (under construction) the string, whose address is popped from top"
"       stack integer."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_.S TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_.S "
"Stack: ( --- )"
"Usage: Add to the current message (under construction) the state of the stack."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE TRACE_PAGE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"TRACE_PAGE "
"Stack: ( --- )"
"Usage: Give control to trace manager to browse recorded messages."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


"DUMP "
"Stack: ( addr1 addr2 --- )"
"   or: ( addr n --- )"
"Usage: Dump in hexadecimal (byte) the memory"
"          - from <addr1> to <addr2>, or"
"          - <n> bytes from <addr>"


"WDUMP "
"       Stack: ( --- )"
"Input stream: WDUMP word_name"
"       Usage: Dump in hexadecimal (byte) the code memory for the given"
"              definition."
"         See: .DIS"
"        Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".DIS "
"       Stack: ( --- )"
"Input stream: .DIS word_name"
"       Usage: Disassemble the code memory for the given definition."
"         See: WDUMP"
"        Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".WHICH "
"Stack: ( addr --- addrz) if word is found"
"    or ( addr --- -1)    if word is not found"
"Usage: If <addr> is a pointer to a memory location where there is E8 ..."
"       (CALL NEAR), then .WHICH returns the symboloc name of the called"
"       FROTH definition (if possible, else -1 is returned)."
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".VOC "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about vocabularies."
"  See: .DDIR .NIA .CREF .CDA"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".DDIR "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about data allocation."
"  See: .VOC .NIA .CREF .CDA"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".NIA "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about Names Info Area (NIA)."
"  See: .VOC .DDIR .CREF .CDA"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".CREF "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about cross reference."
"  See: .VOC .DDIR .NIA .CDA"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


".CDA "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about code area (dump)."
"  See: .VOC .DDIR .NIA .CREF"
" Note: This word is not available into the froth turnkey edition (FROTHT.exe)"


""
;
