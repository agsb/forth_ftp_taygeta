char* STACK =


"?ENOUGHT "
"Stack: ( n --- )"
"Usage: On safe version of FROTH, this immediate word compile a run-time word"
"      (rt_?enought) which verify that there is at least <n> numbers on the"
"      stack. On not safe version of FROTH, this word strip the number"
"      compiled before, in the current word being defined."
"  See: RT_?ENOUGHT DEPTH"


"DROP "
"Stack: ( n --- )"
"Usage: Drop the top value from stack."
"  See: UNDER BELOW DDROP DROPS"


"DROPS "
"Stack: ( n --- )"
"Usage: Drop the <n> top values from stack."
"  See: UNDER BELOW DDROP"


"DDROP "
"Stack: ( n1 n2 --- )"
"Usage: Drop the top two values from stack."
"  See: UNDER BELOW DROP DROPS"


"DUP "
"Stack: ( n --- n n )"
"Usage: Duplicate the value on top of stack."
"  See: OVER ABOVE PICK"


"DDUP "
"Stack: ( n1 n2 --- n1 n2 n1 n2 )"
"Usage: Duplicate the two top values on stack"
"  See: DDUP"


"PICK "
"Stack: ( ... n --- ... n2 )"
"Usage: Duplicate the n-th value under top of stack."
"  See: DUP OVER ABOVE"
" Note: DUP   is defined as  : DUP 1 PICK ;"
"       OVER  is defined as  : OVER 2 PICK ;"
"       ABOVE is defined as  : ABOVE 3 PICK ;"


"DEPTH "
"Stack: ( --- n )"
"Usage: Push the number of integer on the stack (before the call of depth)."


"SWAP "
"Stack: ( n1 n2 --- n2 n1 )"
"Usage: Swap the two values on top of stack."
"  See: DSWAP"


"DSWAP "
"Stack: ( n1 n2 n3 n4 --- n3 n4 n1 n2 )"
"Usage: Swap the four values on top of stack."
"  See: SWAP"


"OVER "
"Stack: ( n1 n2 --- n1 n2 n1 )"
"Usage: Duplicate the value under the top of stack."
"  See: DUP ABOVE PICK"


"ABOVE "
"Stack: ( n1 n2 n3 --- n1 n2 n3 n1 )"
"Usage: Duplicate the value under the under the top of stack."
"  See: DUP OVER PICK"


"UNDER "
" Stack: ( n1 n2 --- n2 )"
" Usage: Drop the value under the top of stack."
"   See: DROP SWAP BELOW"
" Alias: NIP"


"NIP "
" Stack: ( n1 n2 --- n2 )"
" Usage: Drop the value under the top of stack."
"   See: DROP SWAP BELOW"
" Alias: UNDER"


"BELOW "
"Stack: ( n1 n2 n3 --- n2 n3 )"
"Usage: Drop the value under the under the top of stack."
"  See: DROP SWAP UNDER"


"TUCK "
"Stack: ( n1 n2 --- n2 n1 n2 )"
"Usage: Make a SWAP then OVER."
"  See: SWAP OVER"


"ROT "
"Stack: ( n1 n2 n3 --- n2 n3 n1 )"
"Usage: Rotate the three top values on stack."


"-ROT "
"Stack: ( n1 n2 n3 --- n3 n1 n2 )"
"Usage: Rotate the three top values on stack."


"ROLL "
"Stack: ( n --- )"
"Usage: Rotate the <n> top values on stack."
" Note: ROT is defined as:  : ROT 3 ROLL ;"


"-ROLL "
"Stack: ( n --- )"
"Usage: Rotate the <n> top values on stack."
" Note: -ROT is defined as:  : -ROT 3 -ROLL ;"


" >R"
"    Stack: ( n --- )"
"2nd stack: ( --- n )"
"    Usage: Copy top value from parameters stack to 2nd stack."
"      See: R> R RSWAP RDUP ROVER RDROP RUNDER RABOVE RROT R-ROT"


" R>"
"    Stack: ( --- n )"
"2nd stack: ( n --- )"
"    Usage: Copy top value from 2nd stack to parameters stack."
"      See: >R R RSWAP RDUP ROVER RDROP RUNDER RABOVE RROT R-ROT"


" R "
"    Stack: ( --- n )"
"2nd stack: ( n --- n )"
"    Usage: Duplicate top value from 2nd stack to parameters stack."
"      See: >R R> RSWAP RDUP ROVER RDROP RUNDER RABOVE RROT R-ROT"


" RDUP "
"    Stack: ( --- )"
"2nd stack: ( n --- n n )"
"    Usage: Duplicate top value from 2nd stack to 2nd stack stack."
"      See: >R R> R RSWAP ROVER RDROP RUNDER RABOVE RROT R-ROT"


" RSWAP "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 --- n2 n1 )"
"    Usage: Swap the two top values on 2nd stack."
"      See: >R R> R RDUP ROVER RDROP RUNDER RABOVE RROT R-ROT"


" RDROP "
"    Stack: ( --- )"
"2nd stack: ( n --- )"
"    Usage: Drop the top value on 2nd stack."
"      See: >R R> R RSWAP ROVER RDUP RUNDER RABOVE RROT R-ROT"


" RUNDER "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 --- n2 )"
"    Usage: Drop the under top value on 2nd stack."
"      See: >R R> R RSWAP ROVER RDUP RDROP RBELOW RABOVE RROT R-ROT"


" RBELOW "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 n3 --- n2 n3 )"
"    Usage: Drop the under the under top value on 2nd stack."
"      See: >R R> R RSWAP ROVER RDUP RDROP RUNDER RABOVE RROT R-ROT"


" ROVER "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 --- n1 n2 n1 )"
"    Usage: Duplicate the under top value on 2nd stack."
"      See: >R R> R RSWAP RDROP RDUP RUNDER RABOVE RROT R-ROT"


" RABOVE "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 n3 --- n1 n2 n3 n1 )"
"    Usage: Duplicate the under of under top value on 2nd stack."
"      See: >R R> R RSWAP RDROP RDUP RUNDER ROVER RROT R-ROT"


" RROT "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 n3 --- n2 n3 n1 )"
"    Usage: Rotate the top three values on 2nd stack."
"      See: >R R> R RSWAP RDROP RDUP RUNDER ROVER RABOVE R-ROT"


" R-ROT "
"    Stack: ( --- )"
"2nd stack: ( n1 n2 n3 --- n3 n1 n2 )"
"    Usage: Rotate the top three values on 2nd stack."
"      See: >R R> R RSWAP RDROP RDUP RUNDER ROVER RABOVE RROT"

""
;

