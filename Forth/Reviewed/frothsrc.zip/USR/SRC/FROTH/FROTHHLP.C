#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>


static FILE	*fp1, *fp2;		// File pointer
static int	nbwords;

typedef struct
	{
	long	ptr;
	char	wordname[32+1];
	}
	ITEM;


extern char	*STACK;
extern char	*ARITH;
extern char	*NUMIO;
extern char     *THREADS;
extern char     *CONTROL;
extern char     *MEMORY;
extern char     *SCREEN;
extern char     *FILEIO;
extern char     *COMPILER;
extern char     *VARIED;
extern char     *SERIAL;
extern char     *TRACE;
extern char     *EDITOR;
extern char     *KBDSCR;
extern char     *PORTIO;
extern char     *HGR;
extern char     *STRING;
extern char     *LOCVAR;


void process(char *buffer)
	{
	char	*p = &buffer[1];
	ITEM	item;
	char	c;

	for (;;)
		{

		memset(&item, 0, sizeof(ITEM));
		p = strtok(p, " ");
		if (p == NULL)
			break;

		strcpy(item.wordname, p);
		item.ptr = ftell(fp2);
		fwrite(&item, sizeof(ITEM), 1, fp1);
		nbwords++;

		p += (strlen(p) + 1);
		for (;;)
			{
			c = *(p++);
			if (c != '')
				fprintf(fp2, "%c", c);
			else
				{
				fprintf(fp2, "%c", 0);
				break;
				}
			} // for (;;)

		} // for (;;)

	} // process



int main( void )
        {
	ITEM	item;
	long    n;
	long	ofs, len;

	// Open the help file
	fp1 = fopen("F.IHP", "wb");
	if (fp1 == NULL)
		{
		printf("Can't create help file.\n");
		return (-1);
		} // if

	// Open the help file
	fp2 = fopen("F.HLP", "wb");
	if (fp2 == NULL)
		{
		printf("Can't create help file.\n");
		return (-1);
		} // if

	nbwords = 0;
	process( STACK );
	process( ARITH );
	process( NUMIO );
        process( THREADS );
        process( CONTROL );
        process( MEMORY );
        process( SCREEN );
        process( FILEIO );
        process( COMPILER );
        process( VARIED );
        process( SERIAL );
        process( TRACE );
        process( EDITOR );
        process( KBDSCR );
        process( PORTIO );
        process( HGR );
        process( STRING );
        process( LOCVAR );

	fclose(fp1);
	fclose(fp2);


	// Update the position of each word into file
	// ------------------------------------------

	ofs = (nbwords * sizeof(ITEM)) + sizeof(long);
	fp1 = fopen("F.IHP", "r+b");
	for (n = 0; n < nbwords; n++)
		{
		fseek(fp1, sizeof(ITEM) * n, SEEK_SET);
		fread(&item, sizeof(ITEM), 1, fp1);
		item.ptr += ofs;
		fseek(fp1, sizeof(ITEM) * n, SEEK_SET);
		fwrite(&item, sizeof(ITEM), 1, fp1);
		} // for (n)
	fclose(fp1);


	// Merge the two files into one
	// ----------------------------

	fp2 = fopen("\\froth\\FROTH.HLP", "wb");

	fp1 = fopen("F.IHP", "rb");
	len = filelength(fileno(fp1));
	for (n = 0; n < len; n++)
		putc(getc(fp1), fp2);
	fclose(fp1);

	len = -1;
	fwrite(&len, sizeof(long), 1, fp2);

	fp1 = fopen("F.HLP", "rb");
	len = filelength(fileno(fp1));
	for (n = 0; n < len; n++)
		putc(getc(fp1), fp2);
	fclose(fp1);

	remove("F.IHP");
	remove("H.HLP");

	return (0);

	} // main
