char* VARIED =


"CHARUPPERCASE "
"Stack: ( c1 --- c2 )"
"Usage: Transform a given character to uppercase."
"  See: CHARLOWERCASE $UPPERCASE $LOWERCASE"


"CHARLOWERCASE "
"Stack: ( c1 --- c2 )"
"Usage: Transform a given character to lowercase."
"  See: CHARUPPERCASE $UPPERCASE $LOWERCASE"


"\" "
"Input stream: \" string\""
"       Stack: ( --- addrz )"
"       Usage: Push (if execute state) or compile (if compile state) the"
"              given string (prefixed, delimited with \")."
"  See: .\""
"   Alias: C\" S\""

"C\" \""
"S\" \""


".\" "
"Input stream: .\" string\""
"       Stack: ( --- )"
"       Usage: Print (if execute state) or compile (if compile state) the"
"              given string (prefixed, delimited with \")."
"  See: \""


"GETDATE "
"Stack: ( --- n1 n2 n3 n4 )"
"Usage: Read current date:"
"          - <n1> is the year (1994 for example)"
"          - <n2> is the month (0-11)"
"          - <n3> is the day of the month (1-31)"
"          - <n4> is the day of the week (0=sunday, 1=monday, ...)"
"  See: GETTIME GETTICKS TIME&DATE"


"GETTIME "
"Stack: ( --- n1 n2 n3 n4)"
"Usage: Read current time:"
"          - <n1> is hour"
"          - <n2> is minute"
"          - <n3> is seconde"
"          - <n4> is 1/100 seconds."
"  See: GETDATE GETTICKS TIME&DATE"


"TIME&DATE "
"Stack: ( --- n1 n2 n3 n4 n6)"
"Usage: Read current date and time:"
"          - <n1> is hour"
"          - <n2> is minute"
"          - <n3> is seconde"
"          - <n4> is the day of the month (1-31)"
"          - <n5> is the month (0-11)"
"          - <n6> is the year (1995 for example)"
"  See: GETDATE GETTIME GETTICKS"


"GETTICKS "
"Stack: ( --- n )"
"Usage: Return a value which is incremented by one each msec."
"  See: GETDATE GETTIME TIME&DATE"


"BYE "
"Stack: ( --- )"
"Usage: Return to host operating system (MS/DOS)."


"(BYE) "
"Stack: ( --- )"
"Usage: Return to host operating system (MS/DOS)."


"USE "
"Input stream: USE <definition>"
"       Usage: Show a quick help about a given definition."
"        Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"MEM "
"Stack: ( --- )"
"Usage: Show various informations about the use of the memory by FROTH."
" Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"LIMITS "
"Stack: ( --- )"
"Usage: Show all fixed constant limits of the FROTH system."
" Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"UPDATE "
"Stack: ( --- )"
"Usage: This word modify automatically the sources opened into FROSTED buffers."
"       Each definition header (set by editor command Ctrl-Z) is update with"
"       callers and calleds words."
" Note: This word is not available into the froth turnkey edition (FROTHT.EXE)"


"PEMIT "
"Stack: ( c --- )"
"Usage: Send a given character to // port."
"  See: PTYPE"


"PTYPE "
"Stack: ( addrz --- )"
"Usage: Send a given string to // port."
"  See: PEMIT"


"PMODE "
"Stack: ( --- n )"
"Usage: Return a number which show how about the protected mode is managed:"
"          - n=3  DPMI 32-bits (example: WIN32);"
"          - n=2  VCPI         (example: EMM386.SYS);"
"          - n=1  XMS          (example: HIMEM.SYS)"
"          - n=0  RAW."


"DELAY "
"Stack: ( n --- )"
"Usage: Wait <n> msec. While waiting, YIELD is done to give control to any pending"
"       thread."
"  See: NewThread yield"


"FROTHVERSION "
"Stack: ( n1 n2 n3 --- )"
"Usage: Return the version number of the current version of FROTH."
"       If version is '0.25.b', we have:"
"         n1 = 1"
"         n2 = 25"
"         n3 = 0"
"  See: FROTHDATE"


"FROTHDATE "
"Stack: ( n1 n2 n3 --- )"
"Usage: Return the version date of the current version of FROTH."
"         n1 = year (in 'Jan-05-96' we have n1=1996)"
"         n2 = month (n2=1)"
"         n3 = day (n3=5)"
"  See: FROTHVERSION"


"LANGUAGE "
"Stack: ( --- addr )"
"Usage: This variable can be used by applications to use a given language"
"       for input/output. Although it's not used by FROTH itself, this"
"       variable is initialized at the 'English' value."
"  See: English French"


"ENGLISH "
"Stack: ( --- n )"
"Usage: This constant is used with the variable 'Language'."
"  See: Language French"


"FRENCH "
"Stack: ( --- n )"
"Usage: This constant is used with the variable 'Language'."
"  See: Language English"


"?TURNKEY "
"Stack: ( --- f )"
"Usage: Return the true flag is running a turnkey application."
"  See: SAVE.EXE #CmdArgs CmdArgs$"


"#CmdArgs "
"Stack: ( --- n )"
"Usage: Return the number of arguments given in the command line."
"  See: ?turnkey CmdArgs$"


"CmdArgs$ "
"Stack: ( n --- addrz )"
"Usage: Return the n-th argument given from the command line (n starts"
"       from 0 and might not be >= to #CMDARGS else NULLSTR$ is"
"       returned)."
"  See: ?turnkey CmdArgs$ NULLSTR$"


""
;
