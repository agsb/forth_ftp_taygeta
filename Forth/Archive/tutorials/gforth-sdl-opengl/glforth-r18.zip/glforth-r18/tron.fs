\ ===================================================================
\      Program: tron.fs
\       Author: Gerald Wodni
\         Date: 2008
\  Description: 3D Demo Engine for gforth
\             : OpenGL Tron Observers
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================

: tron-right-foot
	gl-quad-strip
		\ frontside
		 \ 0.e0 0.e0 1.e0 gl-normal 
		 2  0  1 gl-vertex-3n
		 0  0  1 gl-vertex-3n
		 2  1  1 gl-vertex-3n
		 1  1  1 gl-vertex-3n
		 2  4  1 gl-vertex-3n
		 1  4  1 gl-vertex-3n
	gl-end
	gl-quad-strip
		\ frontside
		 \ 0.e0 0.e0 1.e0 gl-normal 
		 0  0  -1 gl-vertex-3n
		 2  0  -1 gl-vertex-3n
		 1  1  -1 gl-vertex-3n
		 2  1  -1 gl-vertex-3n
		 1  4  -1 gl-vertex-3n
		 2  4  -1 gl-vertex-3n
	gl-end
	gl-quads
		\ rightside
		\ 0.e0 1.e0 0.e0 gl-normal 
		2  0 -1 gl-vertex-3n		
		2  0  1 gl-vertex-3n
		2  4  1 gl-vertex-3n
		2  4 -1 gl-vertex-3n

		\ left-upper-side
		\ 0.e0 -1.e0 0.e0 gl-normal 
		1  4 -1 gl-vertex-3n
		1  4  1 gl-vertex-3n
		1  1  1 gl-vertex-3n
		1  1 -1 gl-vertex-3n

		\ left-lower-side
		\ -1.e0 1.e0 0.e0 gl-normal 		
		1  1 -1 gl-vertex-3n
		1  1  1 gl-vertex-3n
	        0  0  1 gl-vertex-3n 
	        0  0 -1 gl-vertex-3n

		\ bottom
		0  0  1 gl-vertex-3n
		2  0  1 gl-vertex-3n
		2  0 -1 gl-vertex-3n
		0  0 -1 gl-vertex-3n
	gl-end ;

: tron-left-foot
	180.e0 0.e0 1.e0 0.e0 gl-rotate
	tron-right-foot
	-180.e0 0.e0 1.e0 0.e0 gl-rotate
	;

: tron-bridge1
	gl-quads
		\ front	
		-42.e-1  0.e0   1.e0  gl-vertex-3r
		-42.e-1  5.e-1  14.e-1  gl-vertex-3r
		 42.e-1  5.e-1  14.e-1  gl-vertex-3r
		 42.e-1  0.e0   1.e0  gl-vertex-3r

		\ top
		-42.e-1  5.e-1	14.e-1  gl-vertex-3r
		-42.e-1  5.e-1  -1.e0   gl-vertex-3r
		 42.e-1  5.e-1  -1.e0   gl-vertex-3r
		 42.e-1  5.e-1	14.e-1  gl-vertex-3r

		\ left
		-42.e-1  5.e-1   -1.e0  gl-vertex-3r
		-42.e-1  5.e-1	14.e-1  gl-vertex-3r
		-42.e-1   0.e0	  1.e0  gl-vertex-3r
		-42.e-1   0.e0   -1.e0  gl-vertex-3r

		\ right
		42.e-1  5.e-1	14.e-1  gl-vertex-3r
		42.e-1  5.e-1    -1.e0  gl-vertex-3r
		42.e-1   0.e0    -1.e0  gl-vertex-3r
		42.e-1   0.e0	  1.e0  gl-vertex-3r

		\ bottom
		-42.e-1	 0.e0	-1.e0	gl-vertex-3r
		-42.e-1	 0.e0	 1.e0	gl-vertex-3r
		42.e-1	 0.e0	 1.e0	gl-vertex-3r
		42.e-1	 0.e0	-1.e0	gl-vertex-3r
		
		\ back
		-42.e-1	 5.e-1	-1.e0	gl-vertex-3r
		-42.e-1	 0.e0	-1.e0	gl-vertex-3r
		42.e-1	 0.e0	-1.e0	gl-vertex-3r
		42.e-1	 5.e-1	-1.e0	gl-vertex-3r
	gl-end ;

: tron-bridge2
	gl-quad-strip
		\ front	
		10.e-1  1.e0   1.e0  gl-vertex-3r
		2.e0    1.e0   1.e0  gl-vertex-3r
		5.e-1	5.e-1  1.e0  gl-vertex-3r		
		15.e-1  0.e0   1.e0  gl-vertex-3r		
		-5.e-1	5.e-1  1.e0  gl-vertex-3r	
		-15.e-1 0.e0   1.e0  gl-vertex-3r		
	       	-10.e-1	1.e0   1.e0  gl-vertex-3r
	       	-2.e0	1.e0   1.e0  gl-vertex-3r						
	gl-end

	gl-quad-strip
		\ top
		2.e0    1.e0  -1.e0  gl-vertex-3r
		2.e0    1.e0   1.e0  gl-vertex-3r
	      	10.e-1  1.e0  -1.e0  gl-vertex-3r
	     	10.e-1  1.e0   1.e0  gl-vertex-3r
	     	5.e-1	5.e-1 -1.e0  gl-vertex-3r
	      	5.e-1	5.e-1  1.e0  gl-vertex-3r
	       -5.e-1	5.e-1 -1.e0  gl-vertex-3r
	       -5.e-1	5.e-1  1.e0  gl-vertex-3r
	       -10.e-1	1.e0  -1.e0  gl-vertex-3r
	       -10.e-1	1.e0   1.e0  gl-vertex-3r
		-2.e0	1.e0  -1.e0  gl-vertex-3r
		-2.e0	1.e0   1.e0  gl-vertex-3r
		-15.e-1 0.e0  -1.e0  gl-vertex-3r
		-15.e-1 0.e0   1.e0  gl-vertex-3r
		15.e-1  0.e0  -1.e0  gl-vertex-3r
		15.e-1  0.e0   1.e0  gl-vertex-3r
		2.e0    1.e0  -1.e0  gl-vertex-3r
		2.e0    1.e0   1.e0  gl-vertex-3r
	gl-end

	gl-quad-strip
		\ back
		2.e0    1.e0   -1.e0  gl-vertex-3r
		10.e-1  1.e0   -1.e0  gl-vertex-3r
		15.e-1  0.e0   -1.e0  gl-vertex-3r		
		5.e-1	5.e-1  -1.e0  gl-vertex-3r		
		-15.e-1 0.e0   -1.e0  gl-vertex-3r		
		-5.e-1	5.e-1  -1.e0  gl-vertex-3r	
	       	-2.e0	1.e0   -1.e0  gl-vertex-3r						
	       	-10.e-1	1.e0   -1.e0  gl-vertex-3r
	gl-end ;

: tron-bridge3
	gl-quads
		\ front
		-42.e-1  0.e0   1.e0  gl-vertex-3r
		-42.e-1  5.e-1  1.e0  gl-vertex-3r
		 42.e-1  5.e-1  1.e0  gl-vertex-3r
		 42.e-1  0.e0   1.e0  gl-vertex-3r
		\ back
		-42.e-1  5.e-1  -1.e0  gl-vertex-3r
		-42.e-1  0.e0   -1.e0  gl-vertex-3r
		 42.e-1  0.e0   -1.e0  gl-vertex-3r
		 42.e-1  5.e-1  -1.e0  gl-vertex-3r
	gl-end

	gl-quad-strip
	\ surface
		-42.e-1  0.e0  -1.e0  gl-vertex-3r
		-42.e-1  0.e0   1.e0  gl-vertex-3r	
		 42.e-1  0.e0  -1.e0  gl-vertex-3r
		 42.e-1  0.e0   1.e0  gl-vertex-3r	
		 42.e-1  5.e-1 -1.e0  gl-vertex-3r
		 42.e-1  5.e-1  1.e0  gl-vertex-3r
		  0.e0	 5.e-1 -1.e0  gl-vertex-3r
		  0.e0	 5.e-1  1.e0  gl-vertex-3r
		-42.e-1  5.e-1 -1.e0  gl-vertex-3r
		-42.e-1  5.e-1  1.e0  gl-vertex-3r
		-42.e-1  0.e0 -1.e0  gl-vertex-3r
		-42.e-1  0.e0  1.e0  gl-vertex-3r
	gl-end ;

: tron-top
	90.e0 1.e0 0.e0 0.e0 gl-rotate
	6 cone-draw
	-90.e0 1.e0 0.e0 0.e0 gl-rotate
	;

: tron-draw	
	0.e0 -9.e-1 0.e0  gl-translate
	25.e-2 25.e-2 25.e-2 gl-scale
	2.e0 0.e0 0.e0	gl-translate	
	tron-right-foot
	-4.e0 0.e0 0.e0 gl-translate
	tron-left-foot	
	2.e0 0.e0 0.e0 gl-translate
	
	0.e0 4.e0 0.e0 gl-translate
	tron-bridge1

	0.e0 5.e-1 0.e0 gl-translate
	tron-bridge2
	
	0.e0 1.e0 0.e0 gl-translate
	tron-bridge3


	0.e0 15.e-1 0.e0 gl-translate
	tron-top
	0.e0 -70.e-1 0.e0 gl-translate

	4.e0 4.e0 4.e0 gl-scale
	0.e0 9.e-1 0.e0  gl-translate
	;

