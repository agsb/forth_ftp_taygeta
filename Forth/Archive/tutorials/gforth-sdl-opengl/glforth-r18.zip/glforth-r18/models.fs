\ ===================================================================
\      Program: models.fs
\       Author: Gerald Wodni
\         Date: 2008
\     Modified: 01/24/2010 Timothy Trussell
\  Description: 3D Demo Engine for gforth
\             : Collection of all used model-files
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================
require primitives.fs
require world.fs
require human.fs
require tron.fs

