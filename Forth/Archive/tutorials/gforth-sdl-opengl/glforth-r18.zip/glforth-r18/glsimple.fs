\ ===================================================================
\      Program: glsimple.fs
\       Author: Gerald Wodni
\         Date: 2008
\     Modified: 01/24/2010 Timothy Trussell
\  Description: 3D Demo Engine for gforth
\             : OpenGL basic functions
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================
require gl_r18.fs

: gl-lines		GL_LINES	gl-begin ;
: gl-line-loop		GL_LINE_LOOP	gl-begin ;
: gl-line-strip		GL_LINE_STRIP	gl-begin ;
: gl-quads		GL_QUADS	gl-begin ;
: gl-quad-strip		GL_QUAD_STRIP	gl-begin ;
: gl-triangles		GL_TRIANGLES	gl-begin ;
: gl-triangle-fan	GL_TRIANGLE_FAN	gl-begin ;

: gl-rotate-x		1.e0 0.e0 0.e0	gl-rotate ;
: gl-rotate-y		0.e0 1.e0 0.e0	gl-rotate ;
: gl-rotate-z		0.e0 0.e0 1.e0	gl-rotate ;

