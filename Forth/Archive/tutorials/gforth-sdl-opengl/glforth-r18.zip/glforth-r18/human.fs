\ ===================================================================
\      Program: human.fs
\       Author: Daniel Abouakil
\         Date: 2008
\     Modified: 01/24/2010 Timothy Trussell
\  Description: 3D Demo Engine for gforth
\             : Draws a human
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================
: human-head
	0.e0 125.e-2  0.e0 gl-translate
	25.e-2 25.e-2 25.e-2 gl-scale
	cube-draw
	4.e0 4.e0 4.e0 gl-scale
	0.e0 -125.e-2  0.e0 gl-translate
;

: human-tail
	0.e0 5.e-1  0.e0 gl-translate
	5.e-1 5.e-1 25.e-2 gl-scale
	cube-draw
	2.e0 2.e0 4.e0 gl-scale
	0.e0 -5.e-1  0.e0 gl-translate
;

: human-foot
	125.e-3 5.e-1 125.e-3 gl-scale
	cube-draw
	8.e0 2.e0 8.e0 gl-scale
;

: human-feet
	\ move to feet hight center
	0.e0 -5.e-1  0.e0 gl-translate

	\ translate to left part and draw
	-25.e-2 0.e0  0.e0 gl-translate
	human-foot
	
	\ translate to right part and draw
	50.e-2 0.e0  0.e0 gl-translate
	human-foot

	-25.e-2 5.e-1  0.e0 gl-translate
;

: human-arm
	25.e-2 125.e-3 125.e-3 gl-scale
	cube-draw
	4.e0 8.e0 8.e0 gl-scale
;

: human-arms
	-75.e-2 60.e-2  0.e0 gl-translate
	human-arm

	150.e-2 0.e0  0.e0 gl-translate
	human-arm

	-75.e-2 -60.e-2  0.e0 gl-translate
;

: human-eyes
	gl_POINT gl-begin
	0.e0 1.e0 0.e0 1.e0 gl-color-4r	
	5.e0 gl-point-size
	1 1  1 gl-vertex-3n
	gl-end
;

: human-draw
 	human-feet
	human-tail
	human-head
	human-arms
	human-eyes
;
	
