\ ===================================================================
\      Program: sdl.fs
\       Author: Gerald Wodni
\         Date: 2008
\  Description: 3D Demo Engine for gforth
\             : SDL Interface for gforth
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================
c-library sdl_r18

s" SDL" add-lib

\c #include <SDL/SDL.h>
\c #include <SDL/SDL_keysym.h>


\ ### General ### 

c-function sdl-get-ticks	SDL_GetTicks		-- n		( -- ticks )
c-function sdl-init		SDL_Init		n -- n		( flags -- error code )
c-function sdl-set-video-mode	SDL_SetVideoMode	n n n n -- a	( width height bpp flags -- surface )
c-function sdl-quit		SDL_Quit		-- void

\ ### Video ###

c-function sdl-gl-set-attribute	SDL_GL_SetAttribute	n n -- n	( attribute value -- error code )
c-function sdl-gl-get-attribute	SDL_GL_GetAttribute	n a -- n	( attribute value-pointer -- error code )
c-function sdl-gl-swap-buffers	SDL_GL_SwapBuffers	-- void
c-function sdl-free-surface     SDL_FreeSurface         a -- void       ( surface -- )


\ ### Events ###

c-function sdl-get-key-state	SDL_GetKeyState		a -- a		( *numkeys -- key-array )
c-function sdl-get-mouse-state	SDL_GetMouseState	a a -- n	( *x *y -- button-bitmask )
c-function sdl-pump-events	SDL_PumpEvents		-- void 
c-function sdl-show-cursor	SDL_ShowCursor		n -- n		( toggle -- status )
c-function sdl-warp-mouse	SDL_WarpMouse		n n -- void	( x y -- )

\ ### WM ###

c-function sdl-wm-set-caption	SDL_WM_SetCaption	a a -- void	( *title *icon -- )

end-c-library

include sdlconstants.fs

