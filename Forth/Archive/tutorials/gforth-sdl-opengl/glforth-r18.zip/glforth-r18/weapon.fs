\ ===================================================================
\      Program: weapon.fs
\       Author: Gerald Wodni
\         Date: 2008
\  Description: 3D Demo Engine for gforth
\             : OpenGL draw weapon
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                           GLForth r18
\ ===================================================================

30	constant weapon-width

: weapon-draw
	( 
	0.e0 1.e0 0.e0 gl-color-3r
	gl-quad-strip
		window-width weapon-width -		0	gl-vertex-2n
		window-width weapon-width - 300 -	0	gl-vertex-2n
		window-width weapon-width - 50 -	300	gl-vertex-2n
		window-width weapon-width - 350 -	300	gl-vertex-2n
	gl-end
	)
	;

