\ ===================================================================
\      Program: glf.fs
\       Author: Victor M. <samsaga2@gmail.com>
\         Date: 12/31/2008
\  Description: 3D SDL/OpenGL Demo for gforth
\             : OpenGL extras
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                              3DDemo
\ ===================================================================

create light4v 4 cells allot

: glf-light4f ( light pname r r r r -- )
    light4v 3 cells +
    dup sf!
    cell - dup sf!
    cell - dup sf!
    cell - dup sf!
    gl-light-fv
;

: glf-list{
    1 gl-gen-lists dup
    GL_COMPILE gl-new-list
;

: }glf-list
    gl-end-list
;

