\ ===================================================================
\      Program: 3ddemo.fs
\       Author: Victor M. <samsaga2@gmail.com>
\         Date: 12/31/2008
\  Description: 3D SDL/OpenGL Demo for gforth
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                              3DDemo
\ ===================================================================

[IFDEF] [3DDemo]
  [3DDemo]
[ENDIF]

marker [3DDemo]

page

\ ===================================================================
\ TODO
\ - background
\ - fonts

cr .( ---[ 3DDEMO.FS ]------------------------------------------------)
cr .( Loading dependancy modules:)
require sdl.fs
cr .(   SDL.FS loaded)
require gl.fs
cr .(   GL.FS loaded)
require glf.fs
cr .(   GLF.FS loaded)
require utils.fs
cr .(   UTILS.FS loaded)

: ENUM+ ( n -- ) create , does> ( -- n ) dup @ constant 1 swap +! ;
: ENUM  ( -- )   0 ENUM+ ;
\ require enum.fs
cr .(   ENUM.FS loaded)
cr .( Dependancy modules loaded successfully!
cr .( ----------------------------------------------------------------)

640 value window-w                               \ screen width value
480 value window-h                              \ screen height value
32  value window-bpp                    \ bits per pixel of this mode
0   value window-fs             \ whether to use window or fullscreen

\ 1024 768 2constant window-size
\ false constant window-fullscreen

variable window-surface
create event sdl-event% allot
variable previous-frame-ticks
variable frame-ticks-lapse
variable fps-ticks
variable fps-count
variable exit-main-loop

fvariable cube-rot 0.0e0 cube-rot f!
variable texture
variable cube-dl

\ ---[ VMode Listing ]-----------------------------------------------
\ If your video card has additional modes (ie, 2048x1600), then add
\ the parameters to the enum list, and to the Set-Mode-Parms table.

enum [vmodes]
[vmodes] 320x200x8
[vmodes] 640x480x8
[vmodes] 800x600x8
[vmodes] 1024x768x8
[vmodes] 1280x1024x8
\ [vmodes] 1600x1200x8

[vmodes] 320x200x16
[vmodes] 640x480x16
[vmodes] 800x600x16
[vmodes] 1024x768x16
[vmodes] 1280x1024x16
\ [vmodes] 1600x1200x16

[vmodes] 320x200x24
[vmodes] 640x480x24
[vmodes] 800x600x24
[vmodes] 1024x768x24
[vmodes] 1280x1024x24
\ [vmodes] 1600x1200x24

[vmodes] 320x200x32
[vmodes] 640x480x32
[vmodes] 800x600x32
[vmodes] 1024x768x32
[vmodes] 1280x1024x32
\ [vmodes] 1600x1200x32
[vmodes] last-mode

: Set-Mode-Parms ( mode -- )
  dup 0 >= over last-mode < AND if
  \ parse if in valid range [0..(last-mode)-1]
    case
      320x200x8    of 320  200  8  endof
      640x480x8    of 640  480  8  endof
      800x600x8    of 800  600  8  endof
      1024x768x8   of 1024 768  8  endof
      1280x1024x8  of 1280 1024 8  endof
\      1600x1200x8  of 1600 1200 8  endof
      320x200x16   of 320  200  16 endof
      640x480x16   of 640  480  16 endof
      800x600x16   of 800  600  16 endof
      1024x768x16  of 1024 768  16 endof
      1280x1024x16 of 1280 1024 16 endof
\      1600x1200x8  of 1600 1200 16 endof
      320x200x24   of 320  200  24 endof
      640x480x24   of 640  480  24 endof
      800x600x24   of 800  600  24 endof
      1024x768x24  of 1024 768  24 endof
      1280x1024x24 of 1280 1024 24 endof
\      1600x1200x8  of 1600 1200 24 endof
      320x200x32   of 320  200  32 endof
      640x480x32   of 640  480  32 endof
      800x600x32   of 800  600  32 endof
      1024x768x32  of 1024 768  32 endof
      1280x1024x32 of 1280 1024 32 endof
\      1600x1200x8  of 1600 1200 32 endof
    endcase
  else
  \ out of range - use default of 640x480x32
    drop
    640 480 32
  then
  to window-bpp
  to window-h
  to window-w
;

: initialize-sdl ( mode -- )
    cr ." Initializing SDL... "
    SDL_INIT_VIDEO sdl-init 0< if abort" initializing SDL" then
    ." ok" cr
;

: resize-window
    0 0 window-w window-h gl-viewport

    \ projection matrix
    GL_PROJECTION gl-matrix-mode
    gl-load-identity

    45.0e0 \ fovy
    window-h window-w n>f n>f f/ \ aspect ratio
    0.1e0 100.0e0 \ znear zfar
    glu-perspective

    \ modelview matrix
    GL_MODELVIEW gl-matrix-mode
    gl-load-identity
;

: create-window
    SDL_GL_DOUBLEBUFFER 1 sdl-gl-set-attribute
    
    ." Creating window... "
    SDL_OPENGL
    SDL_GL_DOUBLEBUFFER or
    SDL_HWPALETTE or
    window-fs if SDL_FULLSCREEN or then >R
    window-w
    window-h
    window-bpp
    R>
    sdl-set-video-mode
    
    dup window-surface !

    s" 3D SDL/OpenGL Demo0" c-string 0 sdl-wm-set-caption
    
    0< if abort" creating window" then
    ." ok" cr

    resize-window
;

: initialize-gl
    GL_SMOOTH gl-shade-model
    0.3e0 0.3e0 0.3e0 0.5e0 gl-clear-color
    1.0e0 gl-clear-depth
    GL_DEPTH_TEST gl-enable
    GL_LEQUAL gl-depth-func
    GL_PERSPECTIVE_CORRECTION_HINT GL_NICEST gl-hint
    GL_TEXTURE_2D gl-enable
;

: setup-lights
    GL_LIGHT1 GL_AMBIENT  0.5e0 0.5e0 0.5e0 1.0e0 glf-light4f
    GL_LIGHT1 GL_DIFFUSE  1.0e0 1.0e0 1.0e0 1.0e0 glf-light4f
    GL_LIGHT1 GL_POSITION 0.0e0 0.0e0 2.0e0 1.0e0 glf-light4f
    GL_LIGHT1 gl-enable
    GL_LIGHTING gl-enable
;

: setup-fps
    previous-frame-ticks @ fps-ticks !
    0 fps-count !
;

: setup-frame-ticks
    sdl-get-ticks previous-frame-ticks !
;

: setup-textures
    s" box.bmp0" c-string sdl-load-bmp
    dup 0= if abort" Error loading image" then >r
    
    1 texture gl-gen-textures
    GL_TEXTURE_2D texture gl-bind-texture

    GL_TEXTURE_2D 0 3
    r@ sdl-surface-w @
    r@ sdl-surface-h @
    0 GL_BGR
    GL_UNSIGNED_BYTE
    r@ sdl-surface-pixels @
    gl-tex-image-2d

    GL_TEXTURE_2D GL_TEXTURE_MIN_FILTER GL_LINEAR_MIPMAP_NEAREST gl-tex-parameter-i
    GL_TEXTURE_2D GL_TEXTURE_MAG_FILTER GL_NEAREST gl-tex-parameter-i

    GL_TEXTURE_2D 3
    r@ sdl-surface-w @
    r@ sdl-surface-h @
    GL_BGR
    GL_UNSIGNED_BYTE
    r@ sdl-surface-pixels @
    glu-build-2d-mipmaps

    r> sdl-free-surface
;

: initialize ( mode -- )
    initialize-sdl
    create-window
    initialize-gl
    setup-lights
    setup-textures
    setup-fps
    setup-frame-ticks
    0 cube-dl !
;

: unitialize
    sdl-quit
;

: update-frame-ticks
    sdl-get-ticks dup previous-frame-ticks @ - swap previous-frame-ticks !
    frame-ticks-lapse !
;

: update-fps
    previous-frame-ticks @ fps-ticks @ - 1000 > if
	fps-count @ . ." fps" cr
	0 fps-count !
	previous-frame-ticks @ fps-ticks !
    else
	fps-count @ 1+ fps-count !
    then
;

: poll-events
    begin
	event sdl-poll-event
    while
	    event sdl-event-type c@
	    case
		sdl-event-quit of exit-main-loop on endof
	    endcase
    repeat
;

: scene{
    GL_COLOR_BUFFER_BIT GL_DEPTH_BUFFER_BIT or gl-clear
;

: }scene
    gl-flush
    sdl-gl-swap-buffers
;

: draw-cube
    GL_QUADS gl-begin
    0.0e0 0.0e0 1.0e0 gl-normal-3f
    0.0e0 0.0e0 gl-tex-coord-2f -1.0e0 -1.0e0  1.0e0 gl-vertex-3f
    1.0e0 0.0e0 gl-tex-coord-2f  1.0e0 -1.0e0  1.0e0 gl-vertex-3f
    1.0e0 1.0e0 gl-tex-coord-2f  1.0e0  1.0e0  1.0e0 gl-vertex-3f
    0.0e0 1.0e0 gl-tex-coord-2f -1.0e0  1.0e0  1.0e0 gl-vertex-3f
    
    0.0e0 0.0e0 -1.0e0 gl-normal-3f
    1.0e0 0.0e0 gl-tex-coord-2f -1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    1.0e0 1.0e0 gl-tex-coord-2f -1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 1.0e0 gl-tex-coord-2f  1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 0.0e0 gl-tex-coord-2f  1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    
    0.0e0 1.0e0 0.0e0 gl-normal-3f
    0.0e0 1.0e0 gl-tex-coord-2f -1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 0.0e0 gl-tex-coord-2f -1.0e0  1.0e0  1.0e0 gl-vertex-3f
    1.0e0 0.0e0 gl-tex-coord-2f  1.0e0  1.0e0  1.0e0 gl-vertex-3f
    1.0e0 1.0e0 gl-tex-coord-2f  1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    
    0.0e0 -1.0e0 0.0e0 gl-normal-3f
    1.0e0 1.0e0 gl-tex-coord-2f -1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 1.0e0 gl-tex-coord-2f  1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 0.0e0 gl-tex-coord-2f  1.0e0 -1.0e0  1.0e0 gl-vertex-3f
    1.0e0 0.0e0 gl-tex-coord-2f -1.0e0 -1.0e0  1.0e0 gl-vertex-3f

    1.0e0 0.0e0 0.0e0 gl-normal-3f
    1.0e0 0.0e0 gl-tex-coord-2f  1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    1.0e0 1.0e0 gl-tex-coord-2f  1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    0.0e0 1.0e0 gl-tex-coord-2f  1.0e0  1.0e0  1.0e0 gl-vertex-3f
    0.0e0 0.0e0 gl-tex-coord-2f  1.0e0 -1.0e0  1.0e0 gl-vertex-3f
    
    -1.0e0 0.0e0 0.0e0 gl-normal-3f
    0.0e0 0.0e0 gl-tex-coord-2f -1.0e0 -1.0e0 -1.0e0 gl-vertex-3f
    1.0e0 0.0e0 gl-tex-coord-2f -1.0e0 -1.0e0  1.0e0 gl-vertex-3f
    1.0e0 1.0e0 gl-tex-coord-2f -1.0e0  1.0e0  1.0e0 gl-vertex-3f
    0.0e0 1.0e0 gl-tex-coord-2f -1.0e0  1.0e0 -1.0e0 gl-vertex-3f
    gl-end
;

: render-cube
    cube-dl @ not if
	." Creating display list... "
	glf-list{
	    draw-cube
	}glf-list cube-dl !
	." ok" cr
    then
    
    GL_TEXTURE_2D texture gl-bind-texture
    
    gl-load-identity
    0.0e0 0.0e0 -5.0e0 gl-translate-f
    cube-rot f@ 1.0e0 1.2e0 1.4e0 gl-rotate-f
    cube-dl @ gl-call-list
;

: render-scene ( ticks -- )
    10.0e0 f/ cube-rot f@ f+ cube-rot f!
    render-cube
;

: main-loop
    exit-main-loop off
    begin
	poll-events
	update-frame-ticks
	
	sdl-get-app-state SDL_APPINPUTFOCUS and if
	    update-fps
	    scene{
	        frame-ticks-lapse @ s>f
	        render-scene
	    }scene
	then
	
	exit-main-loop @
    until
;

: 3dhelp
cr
cr ." ---[ 3DDemo.fs ]---"
cr ." 3DDEMO: 3ddemo"
cr ." -------------------"
cr
;

: 3ddemo
    0 to window-fs
    640x480x32 initialize
    main-loop
    unitialize
    3dhelp
;

3dhelp

