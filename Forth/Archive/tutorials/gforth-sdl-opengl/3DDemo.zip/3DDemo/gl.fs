\ ===================================================================
\      Program: gl.fs
\       Author: Victor M. <samsaga2@gmail.com>
\         Date: 12/31/2008
\  Description: 3D SDL/OpenGL Demo for gforth
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                              3DDemo
\ ===================================================================

 c-library gl_3d

s" GL" add-lib
s" GLU" add-lib

\c #if defined(__APPLE__) && defined(__MACH__)
\c      #include <OpenGL/gl.h>
\c      #include <OpenGL/glu.h>
\c #else
\c      #include <GL/gl.h>
\c      #include <GL/glu.h>
\c #endif

c-function gl-disable           glDisable            n -- void          ( enum-capability -- )
c-function gl-enable            glEnable             n -- void          ( enum-capability -- )
c-function gl-is-enabled        glIsEnabled          n -- n             ( enum-capability -- state )
c-function gl-clear             glClear              n -- void          ( mask -- )
c-function gl-clear-color       glClearColor         r r r r -- void    ( red green blue alpha -- )
c-function gl-flush             glFlush              -- void
c-function gl-shade-model       glShadeModel         n -- void          ( model -- )
c-function gl-clear-depth       glClearDepth         r -- void          ( depth -- )
c-function gl-depth-func        glDepthFunc          n -- void          ( func -- )
c-function gl-hint              glHint               n n -- void        ( n n -- )
c-function gl-light-f           glLightf             n n r -- void      ( light pname param -- )
c-function gl-light-fv          glLightfv            n n a -- void      ( light pname array -- )
 
c-function gl-viewport          glViewport           n n n n -- void    ( left top right bottom -- )
c-function gl-load-identity     glLoadIdentity       -- void
c-function gl-translate-f       glTranslatef         r r r -- void      ( x y z -- )
c-function gl-rotate-f          glRotatef            r r r r -- void    ( r x y z -- )
c-function gl-matrix-mode       glMatrixMode         n -- void          ( mode -- )
c-function glu-perspective      gluPerspective       r r r r -- void    ( fovy aspect znear zfar -- )

c-function gl-begin             glBegin              n -- void          ( type -- )
c-function gl-end               glEnd                -- void
c-function gl-vertex-3f         glVertex3f           r r r -- void      ( x y z -- )
c-function gl-color-3f          glColor3f            r r r -- void      ( r g b -- )
c-function gl-tex-coord-2f      glTexCoord2f         r r -- void        ( u v -- )
c-function gl-normal-3f         glNormal3f           r r r -- void      ( x y z -- )

c-function gl-gen-textures      glGenTextures        n a -- void        ( n textures -- )
c-function gl-bind-texture      glBindTexture        n n -- void        ( target texture -- )
c-function gl-tex-image-2d      glTexImage2D         n n n n n n n n a -- void  ( target level interal-format width height border format type pixels -- )
c-function gl-tex-parameter-i   glTexParameteri      n n n -- void      ( target pname param -- )
c-function glu-build-2d-mipmaps gluBuild2DMipmaps    n n n n n n a -- void ( target intformat width height format type pixels -- ) 

c-function gl-gen-lists         glGenLists           n -- n             ( count -- idlist )
c-function gl-new-list          glNewList            n n -- void        ( idlist flag -- )
c-function gl-end-list          glEndList            -- void
c-function gl-call-list         glCallList           n -- void          ( idlist -- )

end-c-library

include glconstants.fs

