\ ===================================================================
\      Program: utils.fs
\       Author: Victor M. <samsaga2@gmail.com>
\         Date: 12/31/2008
\  Description: 3D SDL/OpenGL Demo for gforth
\             : Auxiliary words
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                              3DDemo
\ ===================================================================

: n>u ( n -- u )
    dup 0< if -1 else 0 then
;

: u>n ( u -- n )
    drop
;

: n>f ( n -- r )
    n>u d>f
;

: f>n ( r -- n )
    f>d u>n
;

: fsquare ( r -- r*r )
    fdup f*
;

: c-string ( addr n -- addr )
    over + 1- 0 swap c!
;

: not ( n -- n )
    if false else true then
;

