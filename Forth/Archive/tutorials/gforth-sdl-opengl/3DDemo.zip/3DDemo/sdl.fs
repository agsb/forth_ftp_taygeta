\ ===================================================================
\      Program: sdl.fs
\       Author: Victor M. <samsaga2@gmail.com>
\         Date: 12/31/2008
\  Description: 3D SDL/OpenGL Demo for gforth
\             : SDL Interface for gforth
\ Forth System: gforth-0.7.0
\    Assembler: Built-in FORTH assembler
\ Linux System: Ubuntu v9.10 i386, kernel 2.6.31-19
\ C++ Compiler: gcc (Ubuntu 4.4.1-4ubuntu9) 4.4.1
\ ===================================================================
\                              3DDemo
\ ===================================================================

c-library sdl_3d

s" SDL" add-lib
\c #include <SDL/SDL.h>

c-function sdl-init		     SDL_Init		     n -- n	     ( flags -- error )
c-function sdl-gl-set-attribute      SDL_GL_SetAttribute     n n -- void     ( n n -- )
c-function sdl-set-video-mode	     SDL_SetVideoMode	     n n n n -- a    ( width height bpp flags -- surface )
c-function sdl-quit		     SDL_Quit		     -- void
c-function sdl-poll-event            SDL_PollEvent           a -- n          ( sdl-event% -- error )
c-function sdl-get-ticks             SDL_GetTicks            -- n            ( -- ticks )
c-function sdl-gl-swap-buffers       SDL_GL_SwapBuffers      -- void
c-function sdl-load-bmp              SDL_LoadBMP             a -- a          ( file -- surface )
c-function sdl-free-surface          SDL_FreeSurface         a -- void       ( surface -- )
c-function sdl-wm-togglefullscreen   SDL_WM_ToggleFullScreen a -- void       ( surface -- )
c-function sdl-wm-set-caption        SDL_WM_SetCaption       a a -- void     ( caption icon -- )
c-function sdl-get-app-state         SDL_GetAppState         -- n            ( -- state )

end-c-library

4 4 2constant int%
2 2 2constant word%
1 1 2constant byte%
cell% 2constant ptr%

struct
    char% field sdl-keysym-scancode
    int% field sdl-keysym-sym
    int% field sdl-keysym-mod
    word% field sdl-keysym-unicode
end-struct sdl-keysym%

struct
    byte% field sdl-active-event-type
    byte% field sdl-active-event-gain
    byte% field sdl-active-event-state
end-struct sdl-active-event%

struct
    byte% field sdl-keyboard-event-type
    byte% field sdl-keyboard-event-which
    byte% field sdl-keyboard-event-state
    sdl-keysym% field sdl-keyboard-event-keysym
end-struct sdl-keyboard-event%

struct
    byte% field sdl-mouse-motion-event-type
    byte% field sdl-mouse-motion-event-which
    byte% field sdl-mouse-motion-event-state
    word% field sdl-mouse-motion-event-x
    word% field sdl-mouse-motion-event-y
    word% field sdl-mouse-motion-event-xrel
    word% field sdl-mouse-motion-event-yrel
end-struct sdl-mouse-motion-event%

struct
    byte% field sdl-mouse-button-event-type
    byte% field sdl-mouse-button-event-which
    byte% field sdl-mouse-button-event-button
    byte% field sdl-mouse-button-event-state
    word% field sdl-mouse-button-event-x
    word% field sdl-mouse-button-event-y
end-struct sdl-mouse-button-event%

struct
    byte% field sdl-joy-axis-event-type
    byte% field sdl-joy-axis-event-which
    byte% field sdl-joy-axis-event-axis
    word% field sdl-joy-axis-event-value
end-struct sdl-joy-axis-event%

struct
    byte% field sdl-joy-ball-event-type
    byte% field sdl-joy-ball-event-which
    byte% field sdl-joy-ball-event-ball
    word% field sdl-joy-ball-event-xrel
    word% field sdl-joy-ball-event-yrel
end-struct sdl-joy-ball-event%

struct
    byte% field sdl-joy-hat-event-type
    byte% field sdl-joy-hat-event-which
    byte% field sdl-joy-hat-event-hat
    byte% field sdl-joy-hat-event-value
end-struct sdl-joy-hat-event%

struct
    byte% field sdl-joy-button-event-type
    byte% field sdl-joy-button-event-which
    byte% field sdl-joy-button-event-button
    byte% field sdl-joy-button-event-state
end-struct sdl-joy-button-event%

struct
    byte% field sdl-resize-event-type
    int% field sdl-resize-event-width
    int% field sdl-resize-event-height
end-struct sdl-resize-event%

struct
    byte% field sdl-expose-event-type
end-struct sdl-expose-event%

struct
    byte% field sdl-quit-event-type
end-struct sdl-quit-event%

struct
    byte% field sdl-user-event-type
    int% field sdl-user-event-code
    ptr% field sdl-user-event-data1
    ptr% field sdl-user-event-data2
end-struct sdl-user-event%

struct
    byte% field sdl-sys-wm-event-type
    ptr% field sdl-sys-wm-event-msg
end-struct sdl-sys-wm-event%

struct
    byte% field sdl-event-type
    sdl-active-event% field sdl-event-active
    sdl-keyboard-event% field sdl-event-key
    sdl-mouse-motion-event% field sdl-event-motion
    sdl-mouse-button-event% field sdl-event-button
    sdl-joy-axis-event% field sdl-event-jaxis
    sdl-joy-ball-event% field sdl-event-jball
    sdl-joy-hat-event% field sdl-event-jhat
    sdl-joy-button-event% field sdl-event-jbutton
    sdl-resize-event% field sdl-event-resize
    sdl-expose-event% field sdl-event-expose
    sdl-quit-event% field sdl-event-quit
    sdl-user-event% field sdl-event-user
    sdl-sys-wm-event% field sdl-event-syswm
end-struct sdl-event%

struct
    int% field sdl-surface-flags
    ptr% field sdl-surface-format
    int% field sdl-surface-w
    int% field sdl-surface-h
    word% field sdl-surface-pitch
    ptr% field sdl-surface-pixels
    \ TODO
end-struct sdl-surface%

include sdlconstants.fs

