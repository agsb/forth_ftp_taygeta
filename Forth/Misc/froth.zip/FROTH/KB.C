
#include <stdio.h>


typedef unsigned char 		UBYTE;
typedef unsigned short int	USHORT;
typedef signed short int	SHORT;

typedef struct
	{
	char	zKeyName[8];
	USHORT	ucScanCode;
	SHORT	ucAsciiCode;
	SHORT	ucShiftCode;
	SHORT	ucCtrlCode;
	SHORT	sunAltCode;
	} KEY;

#include "kb_fr.h"
#include "kb_us.h"

int process(char	*pzFileName,
	   KEY	*psKeys,
	   int	 nSize)
	{
	FILE	*fp;		// File pointer
	SHORT	 nNbRecs;	// Nb of records in the file

	// Create / Open filename
	if ( (fp = fopen(pzFileName, "wb")) == NULL)
		{
		return (-1);
		}

	// Write the nb of records to file
	nNbRecs = nSize / sizeof(KEY);
	fwrite(&nNbRecs, sizeof(SHORT), 1, fp);

	// Write the table to file
	fwrite(psKeys, nSize, 1, fp);

	// Close file
	fclose(fp);

	// OK
	return (0);

	} // process


int main(void)
	{

	process("\\froth\\kb_fr.fkb", fr_gaKeys, sizeof(fr_gaKeys) );
	process("\\froth\\kb_us.fkb", us_gaKeys, sizeof(us_gaKeys) );

	return (0);

	} // main
