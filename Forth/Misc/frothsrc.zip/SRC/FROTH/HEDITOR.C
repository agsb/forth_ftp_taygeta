char* EDITOR =


"ED "
"Stack: ( --- )"
"Usage: Call the built-in source editor, called FROSTED."
"  See: LOAD"


"C_StatusLabels "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       elements on status lines (top and bottom of the screen)."
"  See: C_StatusInfos"
" Note: This definition is stored into EDITOR vocabulary."


"C_StatusInfos "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       data on status lines (top and bottom of the screen): current buffer #, current position, ..."
"  See: C_StatusLabel"
" Note: This definition is stored into EDITOR vocabulary."


"C_NormalText "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       normal edited text."
"  See: C_SelectedText"
" Note: This definition is stored into EDITOR vocabulary."


"C_SelectedText "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       selected edited text."
"  See: C_NormalText"
" Note: This definition is stored into EDITOR vocabulary."


"C_NormHelp "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       normal help text."
"  See: C_AltHelp C_KeysHelp"
" Note: This definition is stored into EDITOR vocabulary."


"C_AltHelp "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       special help text (prefix keys: ^ or @)."
"  See: C_NormalHelp C_KeysHelp"
" Note: This definition is stored into EDITOR vocabulary."


"C_KeysHelp "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED as the color/attribute used to draw"
"       text help (keys)."
"  See: C_NormalHelp C_AltHelp"
" Note: This definition is stored into EDITOR vocabulary."


"VideoMode "
"Stack: ( --- addr )"
"Usage: This variable contains a byte which in interpreted by FROSTED when"
"       starting editor session as the video mode to set (see your video card"
"       documentation). For example, mode 3 is text mode, 25x80, 16 colors."
"       You might choose higher mode, for example the author use the 84 mode,"
"       which is 43x132 on a Paradise SuperVGA card. If the value of the variable"
"       VideoMode is -1, FROSTED keeps previous video mode, and does not change"
"       the video mode."
"  See: ED"

"?DirectVideo "
"Stack: ( --- addr )"
"Usage: This variable contains a boolean which is interpreted by FROSTED to"
"       see if screen update is made directly inside memory video, instead"
"       BIOS access. You might always set this variable with TRUE."
"  See: ED"


"DIR$ "
"Stack: ( --- addrz )"
"Usage: This variable contains a string which is interpreted by FROSTED as"
"       a default directory which is added to files when no explicit directory"
"       is given. Set a null string if no default directory is wanted."
"  See: ED"


"CommentField "
"Stack: ( --- addr )"
"Usage: This variable contains an integer which is interpreted by FROSTED as"
"       the column position where comments start (when given on the same line"
"       of code). This comment field is usually used to describe the stack"
"       protocol. Into FROSTED, the key command ALT � move to comment field."
"  See: ED"


"LinePosAdjust "
"Stack: ( --- addr )"
"Usage: This variable contains an integer which is interpreted by FROSTED as"
"       the line position on screen of an asked line."
"  See: ED"


"EditKey "
"Stack: ( --- addr )"
"Usage: This variable contains an integer which is interpreted by INTERPRET as"
"       asking to enter into editor session (FROSTED)."
"  See: ED"



""
;
