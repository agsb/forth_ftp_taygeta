char* TRACE =


".S "
"Stack: ( --- )"
"Usage: Show all integers available on stack."


"TRACE_CLEAR "
"Stack: ( --- )"
"Usage: Clear all messages previously sent by application to trace manager."
"  See: TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"


"TRACE_BEGIN "
"Stack: ( --- )"
"Usage: Start a message, to be sent to the trace manager. Use after: TRACE_. TRACE_.S and TRACE_TYPE."
"  See: TRACE_CLEAR TRACE_END TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"


"TRACE_END "
"Stack: ( --- )"
"Usage: Send now the message built to the trace manager."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_. TRACE_TYPE TRACE.S TRACE_PAGE"


"TRACE_. "
"Stack: ( n --- )"
"Usage: Add to the current message (under construction) the value on top stack integer."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_TYPE TRACE_.S TRACE_PAGE"


"TRACE_TYPE "
"Stack: ( addrz --- )"
"Usage: Add to the current message (under construction) the string, whose address is popped from top"
"       stack integer."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_.S TRACE_PAGE"


"TRACE_.S "
"Stack: ( --- )"
"Usage: Add to the current message (under construction) the state of the stack."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE TRACE_PAGE"


"TRACE_PAGE "
"Stack: ( --- )"
"Usage: Give control to trace manager to browse recorded messages."
"  See: TRACE_CLEAR TRACE_BEGIN TRACE_END TRACE_. TRACE_TYPE"


"DUMP "
"Stack: ( addr1 addr2 --- )"
"   or: ( addr n --- )"
"Usage: Dump in hexadecimal (byte) the memory"
"          - from <addr1> to <addr2>, or"
"          - <n> bytes from <addr>"


".VOC "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about vocabularies."
"  See: .DDIR .NIA .CREF .CDA"


".DDIR "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about data allocation."
"  See: .VOC .NIA .CREF .CDA"


".NIA "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about Names Info Area (NIA)."
"  See: .VOC .DDIR .CREF .CDA"


".CREF "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about cross reference."
"  See: .VOC .DDIR .NIA .CDA"


".CDA "
"Stack: ( --- )"
"Usage: This is a function only available on debug version of Froth:"
"       show internal informations about code area (dump)."
"  See: .VOC .DDIR .NIA .CREF"


""
;
