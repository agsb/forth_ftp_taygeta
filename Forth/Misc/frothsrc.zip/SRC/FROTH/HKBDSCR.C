char* KBDSCR =

"CtrlBreak_OFF "
"Stack: ( --- )"
"Usage: Do not allow CTRL-BREAK, until CTRLBREAK_REST. They are nestable."
"  See: CTRLBREAL_RESTORE"
"Warning: Ctrl-Break is not available if host is DOS running under Windows."
"    See: pmode"


"CtrlBreak_RESTORE "
"Stack: ( --- )"
"Usage: Allow CTRL-BREAK."
"  See: CTRLBREAL_OFF"
"Warning: Ctrl-Break is not available if host is DOS running under Windows."
"    See: pmode"


"EMIT "
"Stack: ( c --- )"
"Usage: Send character <c> to screen, at current position."
"  See: CR SPACE SPACES"


"CR "
"Stack: ( --- )"
"Usage: Force cursor to goto to the start of next line on screen."
"  See: EMIT SPACE SPACES"


"SPACE "
"Stack: ( --- )"
"Usage: Send space character to screen, at current position."
"  See: EMIT CR SPACES"


"SPACES "
"Stack: ( n --- )"
"Usage: Send <n> space characters to screen, at current position."
"  See: EMIT CR SPACE"


"TYPE "
"   Stack: ( addrz --- )"
"   Usage: Send string starting at address <addrz> to screen."
"     See: EMIT CR SPACE SPACES -TYPE TYPE- CSTRING DSTRING FSTRING $!"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"-TYPE "
"   Stack: ( addrz n --- )"
"   Usage: Send string starting at address <addrz> to screen. The string is"
"          right-justified in a field of length <n>."
"  See: EMIT CR SPACE SPACES TYPE TYPE- CSTRING DSTRING FSTRING $!"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"TYPE- "
"Stack: ( addrz n --- )"
"Usage: Send string starting at address <addrz> to screen. The string is"
"       left-justified in a field of length <n>."
"  See: EMIT CR SPACE SPACES TYPE TYPE- CSTRING DSTRING FSTRING $!"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"KBDFILE "
"Stack: ( addrz --- )"
"Usage: Load a keyboard definition table. For example:"
"         \" \FROTH\KB_FR.FKB\" KBDFILE"
"       load frencj keyboard."


"?ALTKEY "
"Stack: ( --- f )"
"Usage: Return a boolean which tells if the ALT key is down."
"  See: KEY ?KEY ?CtrlKey ?ShiftKey"


"?SHIFTKEY "
"Stack: ( --- f )"
"Usage: Return a boolean which tells if the SHIFT key is down."
"  See: KEY ?KEY ?AltKey ?CtrlKey"


"?CTRLKEY "
"Stack: ( --- f )"
"Usage: Return a boolean which tells if the CTRL key is down."
"  See: KEY ?KEY ?AltKey ?ShiftKey"


"KEY "
"Stack: ( --- c )"
"Usage: Read a key for keyboard. This is a blocking word. Note that this"
"       definition yield to anothers threads, if any, while waiting a"
"       character."
"  See: ?KEY YIELD"


"?KEY "
"Stack: ( --- n )"
"Usage: Return the number of available keys, not still read."
"  See: KEY"


"Shift-ed "
"Stack: ( --- n )"
"Usage: Offset to add to a function key code when this key is shift-ed."
"  See: KEY CTRL-ED ALT-ED KEYPAD-ED"
" Note: This definition is into the vocabulary FKEYS."


"Ctrl-ed "
"Stack: ( --- n )"
"Usage: Offset to add to a function key code when this key is ctrl-ed."
"  See: KEY SHIFT-ED ALT-ED KEYPAD-ED"
" Note: This definition is into the vocabulary FKEYS."


"Alt-ed "
"Stack: ( --- n )"
"Usage: Offset to add to a function key code when this key is alt-ed."
"  See: KEY SHIFT-ED CTRL-ED KEYPAD-ED"
" Note: This definition is into the vocabulary FKEYS."


"KeyPad-ed "
"Stack: ( --- n )"
"Usage: Offset to add to a function key code when this key is made on the"
"       keypad."
"  See: KEY SHIFT-ED CTRL-ED ALT-ED"
" Note: This definition is into the vocabulary FKEYS."


"KEYINDICE "
"Stack: ( c --- n )"
"Usage: The only purpose of this definition is to give an internal indice"
"       for a given character which is to be used by ?KEYSTATE."
"  See: ?KeyState"


"?KEYSTATE "
"Stack: ( n -- f )"
"Usage: Return a boolean telling if the key of indice <n> is held or not."
"       Key indice is given by definition KEYINDICE."
"  See: KeyIndice"


"KEY_ALT_A "
"Stack: ( --- n )"
"Usage: Push on stack the code for the given key."
"  See: All others definitions KEY_..."
" Note: This definition is into the vocabulary FKEYS."

"KEY_ALT_B KEY_ALT_A "
"KEY_ALT_C KEY_ALT_A "
"KEY_ALT_D KEY_ALT_A "
"KEY_ALT_E KEY_ALT_A "
"KEY_ALT_F KEY_ALT_A "
"KEY_ALT_G KEY_ALT_A "
"KEY_ALT_H KEY_ALT_A "
"KEY_ALT_I KEY_ALT_A "
"KEY_ALT_J KEY_ALT_A "
"KEY_ALT_K KEY_ALT_A "
"KEY_ALT_L KEY_ALT_A "
"KEY_ALT_M KEY_ALT_A "
"KEY_ALT_N KEY_ALT_A "
"KEY_ALT_O KEY_ALT_A "
"KEY_ALT_P KEY_ALT_A "
"KEY_ALT_Q KEY_ALT_A "
"KEY_ALT_R KEY_ALT_A "
"KEY_ALT_S KEY_ALT_A "
"KEY_ALT_T KEY_ALT_A "
"KEY_ALT_U KEY_ALT_A "
"KEY_ALT_V KEY_ALT_A "
"KEY_ALT_W KEY_ALT_A "
"KEY_ALT_X KEY_ALT_A "
"KEY_ALT_Y KEY_ALT_A "
"KEY_ALT_Z KEY_ALT_A "

"KEY_INS   KEY_ALT_A "
"KEY_DEL   KEY_ALT_A "
"KEY_HOME  KEY_ALT_A "
"KEY_END   KEY_ALT_A "
"KEY_PGUP  KEY_ALT_A "
"KEY_PGDN  KEY_ALT_A "
"KEY_UP    KEY_ALT_A "
"KEY_DOWN  KEY_ALT_A "
"KEY_LEFT  KEY_ALT_A "
"KEY_RIGHT KEY_ALT_A "
"KEY_ESC   KEY_ALT_A "
"KEY_+     KEY_ALT_A "
"KEY_-     KEY_ALT_A "
"KEY_F1    KEY_ALT_A "
"KEY_F2    KEY_ALT_A "
"KEY_F3    KEY_ALT_A "
"KEY_F4    KEY_ALT_A "
"KEY_F5    KEY_ALT_A "
"KEY_F6    KEY_ALT_A "
"KEY_F7    KEY_ALT_A "
"KEY_F8    KEY_ALT_A "
"KEY_F9    KEY_ALT_A "
"KEY_F10   KEY_ALT_A "
"KEY_F11   KEY_ALT_A "
"KEY_F12   KEY_ALT_A "

""
;
