char* STRING =


"CSTRING "
"       Stack (compile time): ( addrz --- )"
"           Stack (run time): ( --- addrz )"
"Input stream: \" string\" CSTRING myString"
"       Usage: Create a constant string. When called. the constant string"
"              pushed its address on stack."
"    See also: FSTRING DSTRING TYPE $! $ADD"
"    Remember: In FROTH, string are endded by '\\0' (as in C)"

"FSTRING "
"   Stack (compile time): ( n --- )"
"       Stack (run time): ( --- addrz )"
"   Usage: Create a fixed variable string. At creation, is given the max"
"          length of the string. When called, the string pushes its"
"          address on stack. The string length can't exceeds the max"
"              length."
"See also: CSTRING DSTRING TYPE $! $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 30 FSTRING myString"
"          \" Hello world !\" myString $!"
"          myString TYPE"

"DSTRING "
"   Stack (compile time): ( n1 n2 --- )"
"       Stack (run time): ( --- addrz )"
"   Usage: Create a dynamic variable string. At creation, is given the"
"          initial max length of the string (n1) and the increment size"
"          (n2), used when string is growing. As a fixed string, when"
"          called, dynamic the string pushes its address on stack."
"See also: CSTRING FSTRING TYPE $! $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 100 20 DSTRING myString"
"          \" Hello world !\" myString $!"
"          myString TYPE"

"$LEN "
"   Stack: ( addrz --- n )"
"   Usage: Give the current length of the given string."
"See also: CSTRING FSTRING DSTRING $MLEN TYPE $! $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$MLEN "
"   Stack: ( addrz --- n )"
"   Usage: Give the max length allocated for the given string. $MLEN is"
"          above all usefull for fixed strings."
"See also: CSTRING FSTRING DSTRING $LEN TYPE $! $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$! "
"   Stack: ( addrz1 addrz2 --- )"
"   Usage: Copy the string (addrz1) to (addrz2). A run time error occurs"
"          if final length exceeds max length allocated for fixed string."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 30 FSTRING myString"
"          \" Hello world !\" myString $!"
"          myString TYPE"


"$+ "
"   Stack: ( addrz1 addrz2 --- )"
"   Usage: Add the string (addrz1) at the end of the string (addrz2)."
"          A run time error occurs if final length exceeds max length"
"          allocated for fixed string."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! ADD$"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 30 FSTRING myString"
"          \" Hello \" myString $!"
"          \" world !\" myString $ADD"
"          myString TYPE"
"   Alias: $ADD"

"$ADD $+"


"+$ "
"   Stack: ( addrz1 addrz2 --- )"
"   Usage: Add the string (addrz2) at the end of the string (addrz1)."
"          A run time error occurs if final length exceeds max length"
"          allocated for fixed string (but dynamic strings extend"
"          automatically),"
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $ADD"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 30 FSTRING myString"
"          \" Hello \" myString $!"
"          myString \" world !\" +$"
"          myString TYPE"
"   Alias: ADD$"

"ADD$ +$"


"$CONVNB "
"   Stack: ( addrz n1 --- n2 n3 ) on numeric conversion success"
"          ( addrz n1 --- -1 )    on numeric conversion failure"
"   Usage: Try to convert from string (addrz) at offset (n1) to an integer"
"          according to the current base. If success, (n2) is the position"
"          of the first character which stops the conversion, and (n3)"
"          is the number."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! BASE"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: DECIMAL"
"          \" xyz12ab\" CSTRING myString"
"          myString 3 $ConvNb   -->  Stack: 5 12"
"          myString 2 $ConvNb   -->  Stack: -1"


"$FIND "
"   Stack: ( addrz1 addrz2 --- addrz2 n )"
"   Usage: Search the string (addrz1) from the beginning of the string (addrz2)."
"          (n) is -1 if not found, else the offset (from 0) of the found"
"          string."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: 30 FSTRING myString"
"          \" Hello world !\" myString $!"
"          \" rl\"  myString $Find   -->  Stack: (addrz) 8"
"          \" rlc\" myString $Find   -->  Stack: (addrz) -1"


"$CopyToChar "
"   Stack: ( addrz n c addrz2 --- )"
"   Usage: Copy to string (addrz2) from string (addrz1) from offset (n)"
"          until character (c) is reached (or the end of the string"
"          if not found). A run time error occurs if final length exceeds"
"          max length allocated for fixed string (but dynamic strings extend"
"          automatically)."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+ $FIND"
"Remember: In FROTH, string are endded by '\\0' (as in C)"
" Example: \" 9876xyz12ab\" CSTRING myString"
"          20 FSTRING str"
"          myString 4 '1 str $CopyToChar   -->  str = \"xyz\""
"          myString 4 'x str $CopyToChar   -->  str = \"xyz12ab\""


"NULL$ "
"   Stack: ( --- addrz )"
"   Usage: Return the address of the null string (length is 0)."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$== "
"   Stack: ( addrz1 addrz2 --- f )"
"   Usage: Compare two strings: return <tf> is they are equal."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+  $== $< $<= $> $>="
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$<= "
"   Stack: ( addrz1 addrz2 --- f )"
"   Usage: Compare two strings: return <tf> is <addrz1> is <= than <addrz2>."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+  $== $< $> $>="
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$< "
"   Stack: ( addrz1 addrz2 --- f )"
"   Usage: Compare two strings: return <tf> is <addrz1> is < than <addrz2>."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+  $== $<= $> $>="
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$>= "
"   Stack: ( addrz1 addrz2 --- f )"
"   Usage: Compare two strings: return <tf> is <addrz1> is >= than <addrz2>."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+  $== $< $<= $>"
"Remember: In FROTH, string are endded by '\\0' (as in C)"


"$> "
"   Stack: ( addrz1 addrz2 --- f )"
"   Usage: Compare two strings: return <tf> is <addrz1> is > than <addrz2>."
"See also: CSTRING DSTRING FSTRING TYPE $LEN $MLEN $! $+  $== $< $<= $>="
"Remember: In FROTH, string are endded by '\\0' (as in C)"


""
;
