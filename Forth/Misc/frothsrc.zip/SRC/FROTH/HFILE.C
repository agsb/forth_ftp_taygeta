char* FILEIO =


"FILEIOSTATUS "
"Stack: ( --- n )"
"Usage: Return the status of the last file I/O definitions ran. Status is"
"      the MS/DOS error code."
"  See: OpenFile CloseFile etc..."


"R/O "
"Stack: ( --- n )"
"Usage: Constant used with OPENFILE to specify that given file is opened"
"       in Read Only mode."
"  See: W/O R/W OpenFile"


"W/O "
"Stack: ( --- n )"
"Usage: Constant used with OPENFILE to specify that given file is opened"
"       in Write Only mode."
"  See: R/O R/W OpenFile"


"R/W "
"Stack: ( --- n )"
"Usage: Constant used with OPENFILE to specify that given file is opened"
"       in Read qnd Write mode."
"  See: R/O W/O OpenFile"


"OpenFile "
"Stack: ( addrz n --- fh )"
"Usage: Open the file with the given filename <addrz>. <n> is access mode"
"       (R/O, W/O or R/W). File is created if access mode is W/O or R/W and"
"       if file does not exist (in this case FILEIOSTATUS has the special"
"       value 3, else 2 if not creation). The file handle is returned if OK,"
"       else -1 if error (see FILEIOSTATUS in this case)."
"  See: FILEIOSTATUS R/O W/O R/W CloseFile ReadFile WriteFile"


"CloseFile "
"Stack: ( fh --- )"
"Usage: Close the file, with given file handle <fh>. FILEIOSTATUS must be"
"       be called to see if no error occured."
"  See: FILEIOSTATUS OpenFile"


"EmitFile "
"Stack: ( fh c --- n )"
"Usage: Send the given character <c> to a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS TypeFile WriteFile OpenFile CloseFile"


"TypeFile "
"Stack: ( fh addrz --- n )"
"Usage: Send the given string <addrz> to a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS EmitFile WriteFile OpenFile CloseFile"


"WriteFile "
"Stack: ( fh addr n1--- n2 )"
"Usage: Send <n1> characters starting at address <addr> to a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters writen to file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS EmitFile TypeFile OpenFile CloseFile"


"ReadFile "
"Stack: ( fh addr n1--- n2 )"
"Usage: Read <n1> characters starting at address <addr> from a given opened file, of file handle <fh>."
"       Is returned the nu;ber of characters read from file, or -1 if error"
"       (in this case, call FILEIOSTATUS to know the error)."
"  See: FILEIOSTATUS WriteFile OpenFile CloseFile"


"SEEKSET "
"Stack: ( --- 0 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from begin of file."
"  See: SEEKCUR SEEKEND SeekFile FilePos"


"SEEKCUR "
"Stack: ( --- 1 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from current pointer position of file."
"  See: SEEKSET SEEKEND SeekFile FilePos"


"SEEKEND "
"Stack: ( --- 2 )"
"Usage: Constant, to be used with SEEKFILE, which has the meaning:"
"       from end of file."


"SeekFile "
"Stack: ( fh n1 n2 --- n3 )"
"Usage: Move file pointer (current position into the file of handle <fh>),"
"       with method <n1> (SEEKSET, SEEKCUR or SEEKEND) and offset <n2>."
"  See: SEEKSET SEEKCUR SEEKEND FilePos"


"FilePos "
"Stack: ( fh --- n )"
"Usage: Return the current position into opened file of handle <fh>. This value is"
"       always expressed from the begin of file."
"  See: SEEKSET SEEKCUR SEEKEND SeekFile FilePos"


"FileSize "
"Stack: ( fh --- n )"
"Usage: Return the length of the opened file of handle <fh>. Calling this word"
"       has NOT the side effect to move file pointer."
"  See: SEEKSET SEEKCUR SEEKEND SeekFile FilePos"


"DeleteFile "
"Stack: ( addrz --- )"
"Usage: Delete a file with given filename <addrz>."
"  See: OpenFile ?FileExist"


"?FileExist "
"Stack: ( addrz --- n )"
"Usage: Return a flag which tells if a file of the given filename <addrz> exists."
"  See: OpenFile"


""
;
