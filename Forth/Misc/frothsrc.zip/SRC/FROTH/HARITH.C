char* ARITH =


"NEGATE "
"Stack: ( n --- -n )"
"Usage: Negate the value on top stack."


"ABS "
"Stack: ( n1 --- n2 )"
"Usage: Return the absolute value of top stack integer."


"MIN "
"Stack: ( n1 n2 --- n3 )"
"Usage: Return the lowest number bewteen two signed integers."
"  See: MAX UMIN UMAX"


"MAX "
"Stack: ( n1 n2 --- n3 )"
"Usage: Return the greatest number bewteen two signed integers."
"  See: MIN UMIN UMAX"


"UMIN "
"Stack: ( n1 n2 --- n3 )"
"Usage: Return the lowest number bewteen two unsigned integers."
"  See: MIN MAX UMAX"


"UMAX "
"Stack: ( n1 n2 --- n3 )"
"Usage: Return the greatest number bewteen two unsigned integers."
"  See: MIN MAX UMIN"


"+ "
"Stack: ( n1 n2 --- n3 )"
"Usage: Add the two top stack integers (n3 = n1 + n2)."
"  See: - 1+ 2+ -"


"1+ "
"Stack: ( n1 --- n2 )"
"Usage: Add one to the integer on top stack (n2 = n1 + 1)."
"  See: +"


"2+ "
"Stack: ( n1 --- n2 )"
"Usage: Add two to the integer on top stack (n2 = n1 + 2)."
"  See: +"


"WordSize+ "
"Stack: ( n1 --- n2 )"
"Usage: Add the integer on top stack with 4 (n2 = n1 + 4)."
"  See: + WordSize"


"- "
"Stack: ( n1 n2 --- n3 )"
"Usage: Subb the two top stack integers (n3 = n1 - n2)."
"  See: + 1- 2-"


"1- "
"Stack: ( n1 --- n2 )"
"Usage: Subb one to the integer on top stack (n2 = n1 - 1)."
"  See: -"


"2- "
"Stack: ( n1 --- n2 )"
"Usage: Subb two to the integer on top stack (n2 = n1 - 2)."
"  See: -"


"WordSize- "
"Stack: ( n1 --- n2 )"
"Usage: Sub the integer on top stack with 4 (n2 = n1 - 4)."
"  See: - WordSize"


"* "
"Stack: ( n1 n2 --- n3 )"
"Usage: Multiply the two top stack integers (n3 = n1 * n2)."


"2* "
"Stack: ( n1 --- n2 )"
"Usage: Multiply the integer on top stack by 2 (n2 = n1 * 2)."
"  See: *"


"WordSize* "
"Stack: ( n1 --- n2 )"
"Usage: Multiply the integer on top stack by 4 (n2 = n1 * 4)."
"  See: * WordSize"


"/ "
"Stack: ( n1 n2 --- n3 )"
"Usage: Divide the two top stack integers (n3 = n1 / n2)."
" Note: A division by zero brings a fatal error."
"  See: MOD /MOD"


"2/ "
"Stack: ( n1 --- n2 )"
"Usage: Divide the integer on top stack by two."
"  See: /"


"WordSize/ "
"Stack: ( n1 --- n2 )"
"Usage: Divide the integer on top stack by 4 (n2 = n1 * 4)."
"  See: * WordSize"


"*/ "
"Stack: ( n1 n2 n3 --- n4 )"
"Usage: Performs the operation (n4 = (n1 * n2) / n3 in double precision."
"  See: */mod"


"*/MOD "
"Stack: ( n1 n2 n3 --- n4 n5 )"
"Usage: Performs the operation (n5 = (n1 * n2) / n3 in double precision"
"       (n4 is the remainder)."
"  See: */mod"


"/MOD "
"Stack: ( n1 n2 --- n3 n4 )"
"Usage: Divide the two top stack integers. Give the remainder (n3) and the quotient (n4)."
" Note: A division by zero brings a fatal error."
"  See: / MOD"


"MOD "
"Stack: ( n1 n2 --- n3 )"
"Usage: Give the remainder of the division of the two top stack integers (n3 = n1 mod n2)."
" Note: A division by zero brings a fatal error."
"  See: / /MOD"


"== "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the two top integers are equal, else push FALSE (0)."
"  See: != < <= > >=  AND OR XOR"
"Alias: ="

"= =="


"!= "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the two top integers are different, else push FALSE (0)."
"  See: == < <= > >=  AND OR XOR"

"<> !="


"< "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is < to top integer, else push FALSE (0)."
"  See: <= > >= >< >=< ><= >=<="


"<= "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is <= to top integer, else push FALSE (0)."
"  See: < > >= >< >=< ><= >=<="


"> "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is > to top integer, else push FALSE (0)."
"  See: < <= >= >< >=< ><= >=<="


">= "
"Stack: ( n1 n2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is >= to top integer, else push FALSE (0)."
"  See: < <= > >< >=< ><= >=<="


">< "
"Stack: ( n1 n2 n3 --- f )"
"Usage: Push TRUE (1) if 'n2 < n1 < n3', else push FALSE (0)."
"  See: < <= > >= >=< ><= >=<="


">=< "
"Stack: ( n1 n2 n3 --- f )"
"Usage: Push TRUE (1) if 'n2 <= n1 < n3', else push FALSE (0)."
"  See: < <= > >= >< ><= >=<="


"><= "
"Stack: ( n1 n2 n3 --- f )"
"Usage: Push TRUE (1) if 'n2 < n1 <= n3', else push FALSE (0)."
"  See: < <= > >= >< >=< >=<="


">=<= "
"Stack: ( n1 n2 n3 --- f )"
"Usage: Push TRUE (1) if 'n2 <= n1 <= n3', else push FALSE (0)."
"  See: < <= > >= >< >=< ><="


"0< "
"Stack: ( n --- f )"
"Usage: Push TRUE (1) if integer is lesser than zero, else push FALSE (0)."
"  See: <= > >= >< >=< ><= >=<="


"0<= "
"Stack: ( n --- f )"
"Usage: Push TRUE (1) if integer is lesser or equal than zero, else push FALSE (0)."
"  See: <= > >= >< >=< ><= >=<="


"0> "
"Stack: ( n --- f )"
"Usage: Push TRUE (1) if integer is greater than zero, else push FALSE (0)."
"  See: <= > >= >< >=< ><= >=<="


"0>= "
"Stack: ( n --- f )"
"Usage: Push TRUE (1) if integer is greater or equal than zero, else push FALSE (0)."
"  See: <= > >= >< >=< ><= >=<="


"U< "
"Stack: ( u1 u2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is < to top integer, else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= <= > >= >< >=< ><= >=<="


"U<= "
"Stack: ( u1 u2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is <= to top integer, else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < > >= >< >=< ><= >=<="


"U> "
"Stack: ( u1 u2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is > to top integer, else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= >= >< >=< ><= >=<="


"U>= "
"Stack: ( u1 u2 --- f )"
"Usage: Push TRUE (1) if the 1st integer is >= to top integer, else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= > >< >=< ><= >=<="


"U>< "
"Stack: ( u1 u2 u3 --- f )"
"Usage: Push TRUE (1) if 'u2 < u1 < u3', else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= > >= >=< ><= >=<="


"U>=< "
"Stack: ( u1 u2 u3 --- f )"
"Usage: Push TRUE (1) if 'u2 <= u1 < u3', else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= > >= >< ><= >=<="


"U><= "
"Stack: ( u1 u2 u3 --- f )"
"Usage: Push TRUE (1) if 'u2 < u1 <= u3', else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= > >= >< >=< >=<="


"U>=<= "
"Stack: ( u1 u2 u3 --- f )"
"Usage: Push TRUE (1) if 'u2 <= u1 <= u3', else push FALSE (0)."
"  See: U< U<= U> U>= U>< U>=< U><= U>=<= < <= > >= >< >=< ><="


"AND "
"Stack: ( n1 n2 --- n3 )"
"Usage: Make AND logical operation between the two top integers (n3 = n1 & n2)."
"  See: OR XOR NOT 0="


"OR "
"Stack: ( n1 n2 --- n3 )"
"Usage: Make OR inclusive logical operation between the two top integers"
"       (n3 = n1 | n2)."
"  See: AND XOR NOT 0="


"XOR "
"Stack: ( n1 n2 --- n3 )"
"Usage: Make OR exclusive logical operation between the two top integers"
"       (n3 = n1 ^ n2)."
"  See: AND OR NOT 0="


"SHL "
"Stack: ( n1 n2 --- n3 )"
"Usage: Make a shift left arithmetic logic operation between the two top integers (n3 = n1 << n2)."
"  See: SHR"


"SHR "
"Stack: ( n1 n2 --- n3 )"
"Usage: Make a shift right arithmetic logic operation between the two top integers (n3 = n1 >> n2)."
"  See: SHL"


"SETBIT "
"Stack: ( n addr --- )"
"Usage: Set the n-th bit, at address <addr>. Bits starts from 0."
"  See: ResetBit ComplBit GetBit  AND OR XOR"


"RESETBIT "
"Stack: ( n addr --- )"
"Usage: Reset the n-th bit, at address <addr>. Bits starts from 0."
"  See: SetBit ComplBit GetBit  AND OR XOR"


"COMPLBIT "
"Stack: ( n addr --- )"
"Usage: Complements the n-th bit, at address <addr>. Bits starts from 0."
"  See: SetBit ResetBit GetBit  AND OR XOR"


"GETBIT "
"Stack: ( n addr --- f )"
"Usage: Return the value of the n-th bit, at address <addr>. Bits starts from 0."
"       Bit value is 0 (reset) or 1 (set)."
"  See: SetBit ResetBit ComplBit  AND OR XOR"


"RND "
"Stack: ( n1 n2 --- n3 )"
"Usage: Compute a random number, between <n1> and <n2>."


"0== "
"Stack: ( n --- f )"
"Usage: Push TRUE (tf=1) if top integer is equal to 0, else push FALSE (ff=0)."
"  See: NOT  (an alias)  0= (another alias)"

"0= 0=="


"0!= "
"Stack: ( n --- f )"
"Usage: Push TRUE (tf=1) if top integer is not equal to 0, else push FALSE (ff=0)."
"Alias: 0<>"

"0<> 0!="


"NOT "
"Stack: ( n --- f )"
"Usage: Push TRUE (tf=1) if top integer is equal to 0, else push FALSE (ff=0)."
"  See: 0==  (an alias)"


"FALSE "
"Stack: ( --- ff )"
"Usage: Push the value 0 (false flag)."
"  See: True On Off"


"TRUE "
"Stack: ( --- tf )"
"Usage: Push the value 1 (true flag)."
"  See: False On Off"


"OFF "
"Stack: ( --- ff )"
"Usage: Push the value 0 (false flag)."
"  See: False True On"


"ON "
"Stack: ( --- tf )"
"Usage: Push the value 1 (true flag)."
"  See: False True Off"



""
;
